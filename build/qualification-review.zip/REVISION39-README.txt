Revision0.0.39-alpha.0, untested prototype, NOT APPROVED TO ORDER.
Latest accepted source: public AnasSarkiz/smart-nema14-motor-controller main.
Latest checks/native sheet renders are revision39/. Retained evidence/,diagnostics/,scripts/,docs/ entries have their ORIGINAL revision37 scope: CAM/silkscreen/USB-return manufacturing screens preserved through exact physical equivalence. They are not a fresh order approval.
Full historical diagnostic payloads, rejected resize JSON, all captured routing inputs and snapshots remain committed in GitHub evidence/rev-0.0.39-alpha.0 and preceding revisions. This runtime ZIP omits their duplicate copies to comply with the registry request-size limit.
Fresh canonical Circuit JSON and every required supplier/model asset remain included separately in the runtime package. Read READINESS.json and BOARD-REVIEW-39.md for incomplete user requirements and blockers.
