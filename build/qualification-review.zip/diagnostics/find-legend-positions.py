import runpy
from pathlib import Path
from pygerber.gerberx3.api.v2 import GerberFile,OnParserErrorEnum
from shapely import affinity
from shapely.geometry import box
read=runpy.run_path('scripts/read-gerber-svg.py')['read_gerber_svg'];shapes={}
for name,path in [('legend',Path('.publication/fix37/legend-audit-cam/F_SilkScreen.gbr')),('mask',Path('.publication/fix36/native-cam-corrected/F_Mask.gbr'))]:
 parsed=GerberFile.from_file(path).parse(on_parser_error=OnParserErrorEnum.Raise);bounds=parsed.get_info();svg=Path('.publication/fix37')/(name+'.svg');parsed.render_svg(svg);sh=read(svg);shapes[name]=affinity.translate(affinity.scale(sh,yfact=-1,origin=(0,0)),float(bounds.min_x_mm),float(bounds.max_y_mm))
legend,mask=shapes['legend'],shapes['mask'];board=box(-17.2,-17.2,17.2,17.2)
for name,region in [('USB-C',box(-14,-17.5,-5,-14)),('SWD',box(11,-6,18,-3))]:
 sh=legend.intersection(region);candidates=[]
 for ix in range(-10,11):
  for iy in range(-20,26):
   dx,dy=ix/10,iy/10;candidate=affinity.translate(sh,dx,dy)
   if board.covers(candidate) and candidate.distance(mask)>=.20:candidates.append((dx*dx+dy*dy,dx,dy,candidate.distance(mask)))
 print(name,sorted(candidates)[:6])
