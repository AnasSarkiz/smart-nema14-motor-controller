import hashlib,json,subprocess
from pathlib import Path
from collections import Counter
old=Path('.publication/rev-0.0.36-alpha.0/dist/index/circuit.json');new=Path('dist/index/circuit.json');a=json.loads(old.read_text());b=json.loads(new.read_text())
# Electrical connectivity is compared as complete equivalence classes, including
# unnamed nets, rather than trusting source_net_id stability.
def partitions(circuit):
 parent={}
 def root(node):
  parent.setdefault(node,node)
  if parent[node]!=node:parent[node]=root(parent[node])
  return parent[node]
 for trace in circuit:
  if trace['type']=='source_trace':
   nodes=trace['connected_source_port_ids']+trace['connected_source_net_ids']
   for node in nodes[1:]:parent[root(node)]=root(nodes[0])
 components={e['source_component_id']:e['name'] for e in circuit if e['type']=='source_component'}
 grouped={}
 for e in circuit:
  if e['type']=='source_port' and e['source_component_id'] in components:
   pin=(components[e['source_component_id']],e.get('pin_number'),tuple(e['port_hints']))
   grouped.setdefault(root(e['source_port_id']),[]).append(pin)
 return sorted([sorted(group,key=repr) for group in grouped.values()],key=repr)
assert partitions(a)==partitions(b)
for kind in ['pcb_smtpad','cad_component']:
 assert [e for e in a if e['type']==kind]==[e for e in b if e['type']==kind],kind
purchased_ids={e['source_component_id'] for e in a if e['type']=='source_component'}
assert [e for e in a if e['type']=='pcb_component' and e['source_component_id'] in purchased_ids]==[e for e in b if e['type']=='pcb_component' and e['source_component_id'] in purchased_ids]
old_vias={e['pcb_via_id']:e for e in a if e['type']=='pcb_via'};new_vias={e['pcb_via_id']:e for e in b if e['type']=='pcb_via'}
changes=[{'id':key,'before':old_vias[key],'after':new_vias[key]} for key in old_vias if old_vias[key]!=new_vias[key]]
assert len(changes)==1 and changes[0]['before']['x']==-11.8 and changes[0]['after']['x']==-11.67
prior_assets=json.loads(Path('evidence/rev-0.0.36-alpha.0/CAD-ASSET-PRESERVATION.json').read_text())
assets=[]
for p in [file['path'] for file in json.loads(Path('evidence/rev-0.0.36-alpha.0/PACKAGE-INVENTORY.json').read_text())['files']]:
 if Path(p).suffix.lower() in ('.obj','.step','.stp'):
  before=subprocess.check_output(['git','show','7b19b40dee5366dac779935c15a291a29b839956:'+p]);after=Path(p).read_bytes();assert before==after,p
  assets.append({'path':p,'sha256':hashlib.sha256(after).hexdigest()})
assert len(assets)==111
report={'baseline_revision':'0.0.36-alpha.0','canonical_sha256':hashlib.sha256(new.read_bytes()).hexdigest(), 'baseline_canonical_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'purchased_pin_count':sum(len(p) for p in partitions(b)), 'all_pin_partitions_preserved':True,'all_111_placements_preserved':True,'all_supplier_pads_and_cad_entries_preserved':True, 'via_changes':changes,'unchanged_via_count':len(old_vias)-1,'all_original_cad_assets':assets,'asset_count':len(assets),'passed':True}
Path('evidence/rev-0.0.37-alpha.0/CHANGE-PRESERVATION.json').write_text(json.dumps(report,indent=2)+'\n');print('Preserved complete electrical partitions, 111 placements, all supplier pads/CAD, 111 original assets and 223 other vias')
