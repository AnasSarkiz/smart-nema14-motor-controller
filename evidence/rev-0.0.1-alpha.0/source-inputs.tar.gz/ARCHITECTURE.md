# Proposed architecture - not implemented or approved

## Power and startup

USB-C connector -> protected sink power path -> motor VM and 3.3 V buck.
Investigate the STM32G0B1 UCPD peripheral with TCPP01-M12 protection; retain
native PD as the proposed architecture. The TCPP01 is protection, not a
standalone PD-negotiation controller. MCU firmware must negotiate contracts.

Default USB 5 V must boot logic while the motor remains disabled by a hardware
pull-up on TMC2209 ENN. Firmware should select an offered PD contract,
prefer 12 V or 15 V when available, verify measured VBUS and negotiated current,
configure the driver and only then permit motion. Requesting 12 V cannot
guarantee that a particular source offers it. Support 9 V and 20 V where
offered. Define a conservative 5 V fallback behavior before enabling the motor.

The startup supply, TCPP dead-battery behavior, MOSFET orientation, inrush,
connector-side capacitance, voltage sensing, overvoltage threshold and power
discharge still need a complete schematic and review. A bulk motor capacitor
must not be connected indiscriminately across unnegotiated VBUS; assess
isolating it with a controlled power path. Do not assume a MOSFET plus TVS
provides complete USB PD or regeneration protection.

Candidate logic regulator: Diodes AP63203WU-7, C780769, fixed 3.3 V with a
32 V operating input limit. Verify its manufacturer datasheet, transient margin,
inductor, loop stability, input capacitance and thermal budget before selecting
its support components. It has not been imported or electrically qualified.

## MCU and interfaces

Candidate STM32G0B1CBT6, C2847904, LQFP48/7 x 7 mm. The manufacturer
datasheet confirms USB FS, UCPD and FDCAN in this family. The 48-pin package
exposes UCPD1 CC pins PA8 and PB15 and USB PA11/PA12. A complete simultaneous
pin allocation is still required; do not allocate USB PA11/PA12 to CAN.

Use MCU-generated STEP/DIR/ENN, UART and DIAG with the TMC2209. Receive
external STEP/DIR and limits through MCU inputs with defined pull states,
protection and documented logic levels. Do not short external STEP/DIR
drivers directly to actively driven MCU outputs.

Candidate CAN transceiver: TI SN65HVD230DR, C12084, 3.3 V. This is a candidate
for classical CAN; no CAN FD data-phase support is claimed. Termination must
be selectable at endpoints. Connector pinout, protection and termination
switch remain unselected.

One USB-C connector should carry PD and USB 2.0 data. Select an exact supplier
connector and independent data ESD protection suitable for this power
architecture. Verify duplicated receptacle USB pins, return paths and the
final 90-ohm differential geometry against the chosen stackup.

## Programming

The official installed package exports `StandardJstSwdResetSide`, backed by
JST SM05B-SRSS-TB(LF)(SN), C136657. Its pinout is:

| Pin | Official signal |
| --- | --- |
| 1 | VOUT |
| 2 | SWDIO |
| 3 | GND |
| 4 | SWCLK |
| 5 | NRST |

**Pin 1 is programmer power output, not a confirmed passive VTREF input.**
The package describes a voltage selector. Resolve 3.3 V-only operation and
backfeed protection before connecting it to the USB-powered logic rail.
Verify the recommended series resistors and programming power arrangement
from the package's source/documentation. They have not been qualified.
No custom SWD connector is proposed.

## Motor current and temperature

0.3-1.0 A/phase is the typical target; 1.2 A/phase continuous is an intended
upper design target, **not a verified operating limit**. Resolve RMS versus
peak current conventions for the motor, driver configuration and advertised
limits. Select external sense resistors after that decision, including their
tolerance, power dissipation and Kelvin return layout.

Provide the manufacturer-specified charge-pump capacitors, VIO and 5VOUT
decoupling, compact VM capacitance, grounded exposed pad, thermal vias and
ground-plane spreading. Select either an NTC/ADC network or a digital sensor
near the driver with firmware thermal shutdown and recovery rules.

A warm motor housing cannot be assumed to cool the driver. No numerical
1.2 A thermal qualification exists yet. Review the heat path, copper area,
ambient conditions and enclosure, then measure driver/PCB/motor temperatures
on an actual prototype. Determine a lower bring-up current before first motion.

Motor deceleration can return energy to VM. USB PD sources are not assumed
to absorb it. Define the load/inertia/speed range and size an energy absorption
or braking arrangement; TVS clamping voltage and energy must protect every
rail-connected component across tolerances.

## Encoder and mechanics

AS5600-ASOM, C79815, is the proposed optional bottom-side I2C encoder.
Its sensing center must align with the actual rear shaft and a diametrically
magnetized magnet. Verify the manufacturer's field-strength/air-gap limits,
package sensing location, magnet holder and assembly tolerance. The center
of a generic SOIC bounding box is not enough evidence.

The only modeled geometry is the requested 35 x 35 mm envelope. No holes
or shaft clearance have been guessed. STEPPERONLINE 14HS13-0804D-PG51 is a
possible reference because its page explicitly specifies a rear shaft and
rear screw holes, but it is a geared model and is **not the selected motor**.
The manufacturer's drawing has not been obtained/reviewed. Front NEMA hole
pitch cannot by itself qualify a rear mounting arrangement.

## Future route corrections

The installed props expose `pcbRouteCache` and native PCB trace/path APIs.
Once prior gates pass, retain each routed circuit JSON and its source/dependency
checksums before changing routes. Correct geometry in supported native source
or route-cache inputs, rebuild, then repeat shorts, clearances, drill-to-copper,
connectivity and visual checks. Never edit Gerbers or erase DRC records to
conceal a fault. No routes exist in this revision to save or edit.

References and the limits of each review are in `references/SOURCES.md`.
