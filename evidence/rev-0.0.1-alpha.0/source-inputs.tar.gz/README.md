# Smart NEMA 14 Motor Controller

Revision `0.0.1-alpha.0`, created 2026-10-02. **Incomplete project, not fabrication ready.**

Standalone USB-C PD stepper controller targeting a 35 x 35 mm, four-layer PCB:
STM32G0B1, TMC2209, bottom-side AS5600, CAN, STEP/DIR, two limit inputs,
temperature monitoring and the official Standard JST SWD + Reset connector.

Read [VALIDATION.md](VALIDATION.md), [issues.md](issues.md),
[ARCHITECTURE.md](ARCHITECTURE.md) and [BOM.md](BOM.md) before continuing.
The original supplied brief is preserved in [references/USER-BRIEF.md](references/USER-BRIEF.md).
The later request authorizes progressing toward fabrication after the earlier
gates pass, including saving and manually correcting routes where needed.

## Current contents

- `index.circuit.tsx`: only a 35 x 35 mm four-layer envelope and a native A4
  sheet explaining the incomplete status. No electronic components, mounting
  holes, wiring, copper planes or routes have been instantiated.
- `imports/`: unmodified outputs of the supported JLCPCB import workflow,
  with downloaded OBJ and STEP assets. MCU and PD-protection imports failed
  review and must not be instantiated yet.
- Official `@tsci/tscircuit.standard-jst-programmer@0.8.0` installed locally.
- `scripts/check-critical-import-pins.mjs`: datasheet comparison of six
  critical imported labels. Its failure blocks build and snapshot scripts.
- `evidence/`: original import outputs, diagnostics and versioned evidence.
- `dist/`: envelope preview only, clearly **not a fabrication output**.

The workspace root has no Git repository. This isolated task directory has
its own local Git repository; no remote, push or publication was created.
Checksums identify this initial revision until a source commit exists.

## Commands

Run every command from this directory. The package scripts use the local,
pinned CLI rather than the older global CLI.

```sh
bun install --frozen-lockfile
bun run format:check
bun run typecheck
bun run validate:imports
bun run build
```

`validate:imports` and `build` currently fail deliberately on real supplier
import discrepancies. Do not suppress those failures or edit component
definitions to make them pass. `bun run preview:envelope` renders only the
incomplete envelope; a successful envelope render is not a board validation.

No fabrication package, completed schematic, populated board preview or
physical test result is available. **Routing remains disabled.**

## What is needed next

1. Correct supplier imports through the supported importer/upstream supplier
   library for C2847904 and C1121848, then re-import and verify them.
2. Identify the actual motor and its rear mounting drawing, rear shaft,
   magnet and standoff geometry.
3. Finish the BOM, power-path and regeneration design, schematic and verified
   placement before enabling routing.
4. Route and measure all copper, run all required checks, visually review the
   resulting layers, then export and review the fabrication package.

An orderable outcome means **ready to order an untested prototype**, not
hardware tested. No order or store publication is authorized by this task.
