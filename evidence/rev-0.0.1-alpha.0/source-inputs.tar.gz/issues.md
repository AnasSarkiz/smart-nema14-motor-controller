# Unresolved issues

## B001 - MCU import loses four critical labels (BLOCKING)

Part **C2847904 / STM32G0B1CBT6**, stage 2 schematic/BOM.
The initial CLI 0.0.2696 output labels pins 6, 7, 33 and 34 as their pin numbers.
Re-import using local CLI 0.0.2729 instead generates empty alias arrays.
ST DS13560 Rev 6 Table 12 identifies these as:

| Physical pin | Manufacturer function | Current imported aliases |
| --- | --- | --- |
| 6 | VDD/VDDA | `[]` |
| 7 | VSS/VSSA | `[]` |
| 33 | PA11 / USB_DM | `[]` |
| 34 | PA12 / USB_DP | `[]` |

The physical pads are present. The demonstrated defect is label loss, not
proof of a physical pad swap or an electrical short. It prevents accepting
the imported symbol and semantic connections under this workspace's rules.
Numerical-pin wiring, prop overrides or custom components are not used to
work around it. Preserve the imports, correct the supported import source or
tool, re-import and re-run review.

## B002 - PD protection import loses control/fault labels (BLOCKING)

Part **C1121848 / TCPP01-M12**, stage 2 schematic/BOM.
Both importer attempts yield `pin10: ["pin10"]` and `pin11: ["pin11"]`.
ST DS12900 Rev 7 Table 1 defines pin 10 as **DB/** (dead-battery management)
and pin 11 as **FLT/** (fault output). These are essential startup/protection
signals. Re-import from a corrected supported source before dependent work.

## B003 - Exact motor and rear mechanical drawing missing (BLOCKING)

Stage 1 requirements and stage 3 placement. No exact user motor model,
reviewed rear drawing, mounting-hole dimensions, rear shaft, shaft/magnet
holder, screw head, standoff height or tolerance stack is available.
The possible STEPPERONLINE reference is not a selected target. No mounting
holes or center cutout have been guessed.

## B004 - Complete schematic and BOM missing (BLOCKING)

Stages 2 and 3. Unresolved supplier imports stop MCU/PD wiring and the
dependent complete circuit. USB-C, support passives, buck inductor, sense
resistors, protection, temperature sensing, LEDs and other connectors remain
unselected. Verify imports, datasheet connections, footprint, 3D registration
and live assembler stock for every component. An envelope is not a schematic.

## B005 - Programmer power semantics unresolved (BLOCKING)

Stages 2 and 3. Official Standard JST SWD Reset Side pin 1 is named VOUT;
the package says it follows the programmer voltage selector. It is not
documented here as passive VTREF. Resolve permissible programmer voltage,
USB/programmer backfeed and required series-resistor guidance before wiring.
The official component remains required and has not been replaced.

## B006 - Current, power and regeneration limits incomplete (BLOCKING)

Stages 1 and 2. Resolve RMS versus peak phase current, motor winding
specifications, maximum speed/load/inertia, PD current budget, 5 V fallback
behavior, allowable temperatures and braking energy. Thermal capability at
1.2 A/phase has not been demonstrated. No tested operating limit is claimed.

## B007 - Stackup and manufactured geometry not qualified (BLOCKING)

Stages 1, 3, 4 and 6. Four layers are requested; dielectric construction,
thickness, copper weight and impedance control are not selected. Proposed
conservative minima are recorded in VALIDATION.md but not applied to any
copper. No USB impedance, power bottleneck, clearance, via, drill or thermal
via measurement can be completed without routed geometry.

## B008 - Datasheet local rendering unavailable

Manufacturer text was accessed with the web tool. Direct ST PDF downloads
failed (HTTP/2 error, timeout); an LCSC TCPP URL returned HTML rather than PDF.
The response is retained as `references/TCPP01-M12-download-error.html`.
No PDF page image has been visually inspected and no package visual review
is claimed. Obtain genuine PDFs before the full symbol/land-pattern review.

## Remaining stages

Placement, copper routing, shorts/DRC, snapshots, Gerber/drill/BOM/CPL review,
assembler feedback and physical testing remain outstanding. There are no
existing routes to save or manually repair. No warning or discrepancy has
been accepted to declare fabrication readiness.
