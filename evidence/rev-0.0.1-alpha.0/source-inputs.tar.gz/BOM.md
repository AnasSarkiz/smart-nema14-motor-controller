# Candidate BOM - NOT READY

Identity checks made 2026-10-02. This is an **incomplete candidate list**;
reference designators below are proposed and no parts are instantiated in
the board. LCSC listings establish identity, not current JLC assembly stock.
Basic/Extended classification, assembler inventory, full package qualification
and component values remain unverified. No supplier numbers have been invented.

| Ref | Function | Manufacturer | MPN | Package | LCSC/JLCPCB Part Number | Basic/Extended | Datasheet | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| U1 | MCU, USB, UCPD, FDCAN | ST | STM32G0B1CBT6 | LQFP48, 7 x 7 mm | C2847904 | Unverified | [ST DS13560](https://www.st.com/resource/en/datasheet/stm32g0b1cb.pdf) | Imported with 3D assets; BLOCKED critical pin-label loss |
| U2 | Stepper driver | ADI/Trinamic | TMC2209-LA | QFN28 exposed pad, 5 x 5 mm | C465949 | Unverified | [ADI Rev 1.09](https://www.analog.com/media/en/technical-documentation/data-sheets/TMC2209_datasheet_rev1.09.pdf) | Imported with 3D assets; full footprint/paste/thermal review pending |
| U3 | USB PD protection | ST | TCPP01-M12 | QFN12 exposed pad, 3 x 3 mm | C1121848 | Unverified | [ST DS12900](https://www.st.com/resource/en/datasheet/tcpp01-m12.pdf) | Imported with 3D assets; BLOCKED DB/FLT label loss; does not negotiate PD alone |
| U4 | Optional magnetic encoder | ams | AS5600-ASOM | SOIC8 | C79815 | Unverified | [Manufacturer-authored datasheet](https://datasheet.lcsc.com/lcsc/1811141115_AMS-AS5600-ASOM_C79815.pdf) | Imported with 3D assets; sensing center, air gap and optional population review pending |
| U5 | 3.3 V buck candidate | Diodes | AP63203WU-7 | TSOT23-6 | C780769 | Unverified | [Supplier entry](https://www.lcsc.com/pl/product-detail/C780769.html) | Identity checked; manufacturer electrical review/import pending |
| U6 | Classical CAN candidate | TI | SN65HVD230DR | SOIC8 | C12084 | Unverified | [TI datasheet](https://www.ti.com/lit/ds/symlink/sn65hvd230.pdf) | Identity checked; full electrical review/import pending; no CAN FD claim |
| J_SWD | Official Standard JST SWD + Reset Side | JST | SM05B-SRSS-TB(LF)(SN) | JST SH 5-pin, 1 mm, side entry | C136657 | Unverified | [JST SH series](https://www.jst-mfg.com/product/pdf/eng/eSH.pdf) | Official package 0.8.0 installed; VOUT/VTREF distinction unresolved |
| J_USB | USB-C PD + USB2 receptacle | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Exact power rating, mount and shaft/edge clearance required |
| Q_PD / power protection | Sink MOSFET, inrush/current and reverse protection | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Complete startup and regenerative-energy design first |
| D_USB | USB data ESD | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Compatible with USB data and high-voltage PD architecture |
| D_VM / brake parts | Motor transient/regen protection | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Voltage margin and energy qualification required |
| L1 | Buck inductor | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Regulator ripple, saturation current and thermal design |
| C_VM | Motor bulk capacitance | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Voltage, ESR, ripple current, inrush and regen requirements |
| C* | VM/logic/charge-pump/encoder/USB/buck decoupling | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Every capacitor needs exact value, rating and supplier import |
| R_SA / R_SB | Current sense | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Clarify RMS/peak current; verify rating and footprint |
| R* | Bias, pull-ups, dividers, SWD/UART/IO support | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Exact per-reference list requires completed schematic |
| R_CAN / termination control | Selectable CAN termination | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | 120 ohm resistor plus verified selectable connection |
| TEMP | Temperature sensor or NTC network | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Thermal trip, fault behavior and sensing placement |
| LED* | Power, status, fault indicators | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Exact LED and current-limiting resistor imports |
| J_IO | Consolidated CAN/STEP/DIR/limits/low-voltage IO | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Final pin count, current and access clearance |
| J_MOTOR | Four-wire motor connection | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Current rating for intended phase-current convention |

The grouped pending rows are a coverage checklist, not an assembly BOM.
Do not export or order them. A complete per-reference BOM must be reviewed
before placement and routing; supplier substitutes require new imports and
validation.
