# Validation - Smart NEMA 14 Motor Controller

Date: **2026-10-02**. Board revision: **0.0.1-alpha.0**.
Status: **BLOCKED; NOT FABRICATION READY; ROUTING DISABLED**.
This is a new design with no source-board predecessor. Local Git is initialized
in this task directory, with no commit or remote. Versioned source/dependency
checksums and an input archive are in `evidence/rev-0.0.1-alpha.0/`.

## Stage record

| Stage | Status | Evidence / outstanding work |
| --- | --- | --- |
| 1. Confirm requirements | blocked | Brief read and preserved; exact motor/rear drawing, current convention, power/thermal envelope and stackup unresolved (B003, B006, B007) |
| 2. Schematic and BOM | blocked | C2847904 and C1121848 imports have six critical label discrepancies (B001/B002); complete circuit and BOM absent; programmer power unresolved |
| 3. Unrouted placement | blocked | Dependent on stages 1/2; no components, mounting holes or mechanical assembly placed |
| 4. Routed copper | not started | Routing explicitly disabled; no copper geometry exists |
| 5. Automated and visual routed checks | not started | Preliminary formatter/typecheck and envelope render completed only; no board electrical/DRC qualification |
| 6. Approve prototype fabrication | not started | No Gerbers, drill files, assembly BOM/CPL or assembler feedback generated |
| 7. Physical prototype tests | not started | No prototype available; no physical evidence or verified operating limit |
| 8. Store release | not started | No release/publish operation; incomplete design |

None of the eight board validation stages has passed.

## Requirements and unresolved limits

The supplied brief requires a motor-mounted standalone controller, STM32G0B1,
TMC2209, real USB-C PD negotiation, USB data where practical, bottom-side
AS5600, CAN, STEP/DIR, two limit inputs, temperature sensing, power/status/fault
LEDs and the official Standard JST programming connector. Target is 35 x 35 mm
and four layers, with accessible edge connectors and exact rear shaft alignment.

- Supply: default 5 V startup; requested 9/12/15/20 V PD where offered. Prefer
  12/15 V operation. Motor disabled until a valid contract, measured voltage,
  current budget and driver setup are confirmed. Detailed inrush/fallback/
  regen behavior remains unresolved.
- Intended phase current: 0.3-1.0 A typical, approximately 1.2 A continuous
  upper design target. RMS/peak convention and physically verified thermal
  limits are unresolved. These are not tested ratings.
- Interface voltage, external-input source impedance and cable protection
  remain to be specified. CAN candidate is classical CAN at 3.3 V logic.
- Mounting: exact motor, rear drawing, screw diameters/heads, shaft clearance,
  standoffs, magnet holder and encoder air gap are unresolved. No holes placed.
- Manufacturer: JLCPCB four-layer rigid FR4, through vias. Proposed L1 component/
  signal/power, L2 GND, L3 power/slow signals, L4 encoder/signals arrangement.
  No plane has been created and no stackup/thickness has been selected.

### Proposed manufacturing rules - not copper validation

Conservative candidate values below must be reconciled with the selected
stackup, imported lands, thermal-via construction and JLCPCB DFM before routing.
The [JLCPCB rigid capability page](https://jlcpcb.com/capabilities/pcb-capabilities/)
was consulted on 2026-10-02; quoted capability minima are not power-current
ratings. Use manufacturer-specific geometry/current analysis for critical nets.

| Feature | Proposed design target | Status |
| --- | --- | --- |
| Signal trace width | At least 0.15 mm except a documented USB impedance design | Not implemented/measured |
| Copper clearance | At least 0.15 mm, with larger spacing where protection needs it | Not implemented/measured |
| Ordinary through via | 0.30 mm drill / 0.60 mm copper diameter | Not implemented/measured |
| Ordinary drill edge-to-copper | At least 0.25 mm, including same-net pads | Not implemented/measured |
| Copper-to-board edge | At least 0.30 mm | Not implemented/measured |
| Thermal via array | Pending; review exposed-pad paste and filling/tenting requirements separately | No exception approved |
| Power trace widths | Pending load, copper weight and thermal calculation; inspect narrow necks | No current-capacity claim |
| USB differential impedance | 90 ohm target on chosen manufacturer stackup | Stackup/routing unselected |

The empty-envelope build defaults to 1.4 mm thickness and the library's own
DRC minima (including 0.10 mm traces and 0.20/0.30 mm via dimensions). These
defaults **are not approved fabrication settings**. Do not generate fabrication
outputs from that envelope or treat them as the rules above.

## Tool/dependency record

| Tool | Version |
| --- | --- |
| Bun | 1.3.9 |
| Initial global tsci | 0.0.2696 |
| Local tscircuit / tsci used for current review and envelope build | 0.0.2729 |
| Local @tscircuit/cli | 0.1.2228 |
| TypeScript | 5.9.3 |
| Biome | 2.5.15 |
| Standard JST Programmer | 0.8.0 |

`package.json` pins these dependencies; `bun.lock` preserves transitive versions.
Installed props/core versions are captured in the revision manifest.
Initial dependency installation emitted peer-version warnings for circuit-json,
React/react-dom and alphabet. No warnings are accepted as evidence of electrical
or fabrication readiness; tool qualification must be revisited for the full board.

## Commands and observed results

Commands were run from this task directory. The package scripts resolve the
local `tsci`; initial direct `tsci` commands used the global CLI.

| Command | Result | Evidence |
| --- | --- | --- |
| `tsci init -y --no-install` | Initialized; automatic AI skill setup failed network access; already supplied skill read separately | Generated config/package/entry; generic electronic sample removed |
| `tsci import --jlcpcb --use-exact-footprint --download C2847904` | Imported; component review BLOCKED | Original import preserved; B001 |
| Same import command for C465949, C1121848, C79815 | Imported with STEP/OBJ assets; PD protection review BLOCKED | Unmodified `imports/`; B002 |
| `tsci add tscircuit/standard-jst-programmer` | Installed official package 0.8.0 | Installed source/types and pinned dependency |
| Local `node_modules/.bin/tsci import ... C2847904` | Re-import success; four labels still missing, now empty arrays | Current import; B001 |
| Local `node_modules/.bin/tsci import ... C1121848` | Re-import success; two control/fault aliases still anonymous | Current import; B002 |
| `bun run format:check` | Passed for authored source/config/audit; imports left unmodified | `evidence/format-check.log` |
| `bun run typecheck` | Passed for current source and imported TSX | `evidence/typecheck.log`; does not establish electrical correctness |
| `bun run validate:imports` | Failed, exit 1; six manufacturer-label discrepancies | `evidence/critical-import-audit.log` |
| `bun run build` | Blocked, exit 1 by critical-import audit; full board build not attempted | `evidence/guarded-build.log` |
| `bun run preview:envelope` | Successful empty-envelope render, routing disabled | `evidence/envelope-build.log`, `dist/index/` |
| `bun install --offline` | Lockfile refreshed after version pinning | `bun.lock`; initial sandbox temp-access failure resolved using narrow escalation |

No checks were suppressed. No imported component definition was patched.
Imports and package identities are recorded in BOM.md; supplier stock/class
checks and full datasheet/footprint/3D reviews remain incomplete.

### Required checks still pending

These checks exist in the installed CLI help. They were not run on the empty
envelope, since their success would not validate a motor controller and stages
1/2 already block dependent circuit construction.

```sh
tsci check netlist index.circuit.tsx
tsci check pin_specification index.circuit.tsx
tsci check source index.circuit.tsx
tsci check schematic-placement index.circuit.tsx
tsci check placement index.circuit.tsx
tsci build index.circuit.tsx --pcb-png --pcb-svgs --schematic-svgs
tsci check shorts dist/index/circuit.json
tsci snapshot index.circuit.tsx
```

Run all of them in their proper stages after the schematic/BOM/mechanics are
resolved. Only routed output from the same source revision can qualify copper,
shorts and routed snapshots. No conclusion about shorts or DRC can be drawn
from the current envelope.

## Artifact inspection

- Visually inspected `dist/index/pcb.png`: empty rectangular envelope only.
- Visually inspected `evidence/schematic-envelope.png`, rendered from the
  native `dist/index/schematic.svg`: readable incomplete/blocked note inside
  a native A4 sheet boundary. It is not an electrical schematic.
- Inspected circuit JSON: one PCB board, width/height 35 mm, four layers;
  one native A4 sheet 297 x 210; zero electronic components, traces or vias.
  JSON inspection is recorded in `evidence/envelope-inspection.json`.
- Downloaded part OBJ/STEP assets have not been visually reviewed.
- Manufacturer PDF text consulted via web. Local PDF acquisition/rendering
  failed as recorded in B008; no rendered datasheet visual review completed.

Accepted warnings: **none**. Unresolved issues: **B001-B008 in issues.md**.

## Readiness

**BOM: NOT READY**  
**SCHEMATIC: NOT READY**  
**MECHANICS: NOT READY**  
**PLACEMENT: NOT READY**  
**ROUTING: DISABLED**  
**FABRICATION: NOT READY**

The workspace AGENTS.md explicitly says: "If a required part cannot be
imported, or an imported component has any issue, report it to the user
explicitly as a blocking issue" and "stop dependent work". The six label
discrepancies trigger that rule. Resolve them through supported imports
before wiring, placement, routing or fabrication work depends on those parts.
