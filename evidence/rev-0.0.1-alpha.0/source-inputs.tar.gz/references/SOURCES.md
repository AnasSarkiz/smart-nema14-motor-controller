# Sources and review scope

Read on 2026-10-02. Web sources may serve cached text; displayed stock counts
are not treated as current assembly inventory or reservations.

| Source | What was established | What remains unverified |
| --- | --- | --- |
| [tscircuit handbook code guide](https://raw.githubusercontent.com/tscircuit/handbook/main/guides/code.md) | Current guide consulted before edits | No handbook exemption invoked |
| [Handbook bootstrapping guide](https://raw.githubusercontent.com/tscircuit/handbook/main/guides/bootstrapping-repos.md) | Repository setup conventions consulted | Board-specific workspace rules govern task isolation |
| [ST STM32G0B1 datasheet DS13560 Rev 6](https://www.st.com/resource/en/datasheet/stm32g0b1cb.pdf) | Table 12 critical pin functions; family interfaces; 48-pin CC availability | Full alternate-function allocation, electrical review and rendered package review |
| [LCSC C2847904](https://lcsc.com/product-detail/Microcontroller-Units-MCUs-MPUs-SOCs_STMicroelectronics-STM32G0B1CBT6_C2847904.html) | Exact MCU identity/package | Live JLC inventory and Basic/Extended classification |
| [ADI TMC2209 Rev 1.09](https://www.analog.com/media/en/technical-documentation/data-sheets/TMC2209_datasheet_rev1.09.pdf) | Pin table, standard support circuit, sense-current and thermal sections consulted | Complete application calculation, footprint and thermal evidence |
| [Supplier-hosted manufacturer TMC2209 datasheet/C465949](https://datasheet.lcsc.com/szlcsc/1912051511_TRINAMIC-Motion-Control-GmbH-TMC2209-LA_C465949.pdf) | Part identity and successful exact supplier import | Live assembler inventory |
| [ST TCPP01 DS12900 Rev 7](https://www.st.com/resource/en/datasheet/tcpp01-m12.pdf) | Table 1 DB/FLT functions and protection/application notes | Complete sink circuit/startup review and rendered land-pattern review |
| [LCSC C1121848](https://www.lcsc.com/product-detail/EMI-Filters-LC-RC-Networks_STMicroelectronics-TCPP01-M12_C1121848.html) | Exact PD protection identity | Live JLC inventory/classification |
| [AS5600 manufacturer-authored datasheet](https://datasheet.lcsc.com/lcsc/1811141115_AMS-AS5600-ASOM_C79815.pdf) | Exact AS5600-ASOM identity and successful supplier import | Complete pin review, magnet design and air gap |
| [AS5600 supplier listing](https://lcsc.com/products/Position-Sensor_11123.html) | C79815 identity | Live JLC inventory/classification |
| [LCSC AP63203 C780769](https://www.lcsc.com/pl/product-detail/C780769.html) | Buck candidate identity/input range | Manufacturer design calculation and import |
| [LCSC TI CAN C12084](https://lcsc.com/product-detail/CAN-ICs_Texas-Instruments-SN65HVD230DR_C12084.html) | Candidate identity; not Tokmas/JSM substitution | Full TI electrical review, import and stock |
| [Required programmer](https://tscircuit.com/tscircuit/standard-jst-programmer) | Direct web view failed; supported CLI installed exact package 0.8.0; installed source/types reviewed | Series resistors and power-mode qualification |
| [LCSC JST C136657](https://www.lcsc.com/product-image/C136657.html) | Five-pin side-entry connector identity agrees with official package source | Mechanical/access and assembler review |
| [Required RP2040 reference](https://tscircuit.com/imrishabh18/rp2040-motor-controller) | Direct web view failed | Source/design reference review remains outstanding; no copying used |
| [STEPPERONLINE rear-shaft reference candidate](https://www.omc-stepperonline.com/nema-14-stepper-l-34mm-w-rear-shaft-screw-hole-gear-ratio-51-1-gearbox-14hs13-0804d-pg51) | Product page specifies rear shaft and rear screw holes | Exact target motor and manufacturer drawing; no hole dimensions adopted |
| [JLCPCB rigid PCB capabilities](https://jlcpcb.com/capabilities/pcb-capabilities/) | Four-layer process, drill/via capability and through-hole-only standard service consulted | Exact ordered stackup, electrical geometry and DFM feedback |

MKS SERVO35D is a concept reference named in the brief; its authoritative
mechanical/circuit documentation has not been qualified for this board.
Downloaded OBJ/STEP files exist for four imported ICs, but their origins,
rotations and body fit have not been visually reviewed.
