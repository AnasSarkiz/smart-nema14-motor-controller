import json,runpy,sys,math
from pathlib import Path
from shapely.geometry import Point,LineString
from shapely.ops import unary_union
sys.argv=['scripts/check-filled-copper.py','dist/index/circuit.json','.publication/fix40/site-search-filled.json'];g=runpy.run_path('scripts/check-filled-copper.py')
c=g['circuit']; names={v:k for k,v in g['net_names'].items()};exclude=[(-1.2,3.2),(1.8207994,2.43500793)]
existing=[(v,n,s) for v,n,s in g['vias'] if not any(math.hypot(v['x']-x,v['y']-y)<1e-5 for x,y in exclude)]
for name,cx,cy in [('GND',1.9207994,2.28500793)]:
 net=names[name];foreign=unary_union([p['shape'] for p in g['conductors'] if p['net']!=net and p['kind']=='trace']);padshapes=unary_union([p['shape'] for p in g['pads']]);sites=[]
 for ix in range(-6,7):
  for iy in range(-6,7):
   x,y=round(cx+ix*.01,7),round(cy+iy*.01,7);p=Point(x,y)
   if p.distance(padshapes)<.5-1e-5:continue
   if p.distance(foreign)<.45-1e-5:continue
   if any(math.hypot(x-v['x'],y-v['y'])<max(.35+(.3+v['hole_diameter'])/2,.15+(.6+v['outer_diameter'])/2)-1e-5 for v,_,_ in existing):continue
   if name=='GND':
    bottom=unary_union([q['shape'] for q in g['conductors'] if q['layer']=='bottom' and q['net']==net]);top=unary_union([q['shape'] for q in g['conductors'] if q['layer']=='top' and q['net']==net])
    if p.distance(bottom)>.25 or p.distance(top)>.25:continue
   margin=min(p.distance(padshapes)-.5,p.distance(foreign)-.45,*[math.hypot(x-v['x'],y-v['y'])-max(.35+(.3+v['hole_diameter'])/2,.15+(.6+v['outer_diameter'])/2) for v,_,_ in existing]);sites.append((-round(margin,6),x,y,round(p.distance(foreign)-.3,6)))
 print(name,sorted(sites)[:15])
