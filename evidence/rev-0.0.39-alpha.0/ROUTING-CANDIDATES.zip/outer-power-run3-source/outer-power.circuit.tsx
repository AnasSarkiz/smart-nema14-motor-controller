import SmartNema14MotorController from "./src/SmartNema14MotorController"
export default function OuterPowerTrial() { return <SmartNema14MotorController nativeRoutingTargets={["net.MOTOR_A1"]} nativeRoutingNetNames={["MOTOR_A1"]} /> }
