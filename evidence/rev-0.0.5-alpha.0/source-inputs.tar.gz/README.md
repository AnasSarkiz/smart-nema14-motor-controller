# Smart NEMA 14 Motor Controller

Revision `0.0.5-alpha.0`, reviewed 2026-10-02. **Schematic draft; not fabrication ready.**

Standalone USB-C PD stepper controller targeting a 35 x 35 mm four-layer PCB:
STM32G0B1, TMC2209, bottom-side AS5600, classical CAN, STEP/DIR, two limits,
temperature monitoring and the official Standard JST SWD + Reset connector.

Read [VALIDATION.md](VALIDATION.md), [issues.md](issues.md),
[ARCHITECTURE.md](ARCHITECTURE.md), [BOM.md](BOM.md) and
[references/MCU-PIN-PLAN.md](references/MCU-PIN-PLAN.md).
The supplied brief is preserved in [references/USER-BRIEF.md](references/USER-BRIEF.md).

## Current contents

- Global tscircuit updated from 0.0.2696 to 0.0.2729, then to 0.0.2732; latest recheck updates global/local to 0.0.2733.
- CLI 0.1.2230 and EasyEDA 0.0.366 are pinned and verified. C2847904 and
  C1121848 were regenerated through the official importer.
  The unchanged critical-label audit passes. Neither definition was manually patched.
- `src/`: five native A4 sheets for MCU core, optional AS5600, classical CAN,
  AP63203 logic regulator and TMC2209 support. They instantiate 38 supplier parts.
  USB-PD protection, programmer power, external IO and connectors remain unfinished.
- `imports/`: generated JLCPCB components; new supplier JSON and prior imports
  retained under versioned `evidence/` directories.
- Official `@tsci/tscircuit.standard-jst-programmer@0.8.0` installed; integration pending.
- `dist/index/schematic-MCU.svg`, `schematic-Encoder.svg`, `schematic-CAN.svg`
  plus `schematic-LogicPower.svg` / `schematic-MotorDriver.svg` and corresponding
  PNGs: reviewed draft sheets.
- No validated PCB placement, mounting holes, shaft clearance, copper or fabrication package.

This task has its own local Git repository, no source commit or remote.
Versioned manifests and source archives identify the reviewed inputs.

## Commands

Run from this board directory:

```sh
bun install --frozen-lockfile
bun run format:check
bun run typecheck
bun run validate:imports
bun run preview:schematic
bun run test:draft
```

`preview:schematic` disables PCB generation and renders each native A4 sheet.
`test:draft` checks the generated physical-pin connections, supplier identities,
A4 sheets and absence of PCB output. These checks do not qualify the complete board.
The full `build` and `snapshot` commands remain available for their later validation
stages; do not use a draft render as placement, routing or fabrication evidence.

## Supported component workflow

Use the pinned official CLI importer containing the released converter fix.
The corrected C5127775 import is a native 0.18 Ω resistor. C19947652 provides
its own Bourns 3.9 µH footprint. C5127776 is an unused 0.15 Ω candidate;
AEC-Q200 qualification is not established.

```sh
tsci upgrade
node_modules/.bin/tsci import C5127775 --jlcpcb --use-exact-footprint
bun run validate:imports
bun run preview:imports
bun run test:imports
node_modules/.bin/tsci check placement scripts/import-audit.circuit.tsx
```

`preview:imports` is an isolated 80 x 35 mm footprint fixture, not this motor
board. Its placement result qualifies only separated component geometry;
full 35 x 35 mm board placement remains gated by exact motor mechanics.
The new audit verifies raw values and all 104 physical pin/pad mappings for
both sense candidates, the replacement inductor, MCU, TCPP01, AS5600 and TMC2209.

Preserve earlier revision evidence before regeneration. Do not hand-edit generated
symbols, pin mappings, footprints or models to repair imports.

## Next gates

The exact motor model and rear drawing are still needed for mounting holes,
shaft/magnet position, screw clearances and standoffs. No geometry has been guessed.
Continue the complete BOM and USB-PD/power/motor/SWD/IO schematic independently.
Current motor draft uses 180 mOhm sense resistors, nominal 1.149 A RMS full scale,
with a proposed 1.0 A firmware cap; the 1.2 A upper target is not qualified.
See [the power review](references/POWER-AND-MOTOR-REVIEW.md) for calculations.
Then qualify footprints, models, stock and placement before enabling routing.
Save routes before manual corrections and repeat all required copper checks afterward.

**BOM NOT READY / SCHEMATIC NOT READY / MECHANICS NOT READY / PLACEMENT NOT READY**  
**ROUTING DISABLED / FABRICATION NOT READY**

An eventual fabrication release means ready to order an **untested prototype**.
No order, physical test result or store publication is part of this revision.

## Latest blocker recheck

Latest published tscircuit 0.0.2733 / core 0.0.2052 was installed and all
applicable draft/fixture checks repeated. Original C2046441/C5127782/C723743
imports still fail; their verified alternatives pass. Fresh AS5600/TMC2209
imports retain two power-metadata warnings. Detailed current outcomes are in
[evidence/rev-0.0.5-alpha.0/BLOCKER-RECHECK.md](evidence/rev-0.0.5-alpha.0/BLOCKER-RECHECK.md).
Motor mechanics and unfinished PD/power/interfaces still gate fabrication.
