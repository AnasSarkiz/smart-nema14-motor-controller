import { CanSheet } from "./src/can/CanSheet"
import { EncoderSheet } from "./src/encoder/EncoderSheet"
import { McuSheet } from "./src/mcu/McuSheet"
import { MotorDriverSheet } from "./src/motor-driver/MotorDriverSheet"
import { LogicBuckSheet } from "./src/power/LogicBuckSheet"

/** Schematic development only. Mechanics and full circuit review gate placement. */
export default function SmartNema14MotorController() {
  return (
    <board
      width="35mm"
      height="35mm"
      layers={4}
      routingDisabled
      schLayout={{ layoutMode: "none" }}
    >
      <net name="GND" isGroundNet />
      <net name="V3V3" isPowerNet />
      <net name="NRST" />
      <net name="I2C_SCL" />
      <net name="I2C_SDA" />
      <net name="CAN_TX" />
      <net name="CAN_RX" />
      <net name="CAN_H" />
      <net name="CAN_L" />
      <net name="VBUS_INRUSH_OUT" isPowerNet />
      <net name="BUCK_SW" />
      <net name="BUCK_BST" />
      <net name="VM" isPowerNet />
      <net name="TMC_ENABLE_N" />
      <net name="TMC_STEP" />
      <net name="TMC_DIR" />
      <net name="TMC_DIAG" />
      <net name="TMC_UART_TX" />
      <net name="TMC_UART_RX" />
      <net name="TMC_CPO" />
      <net name="TMC_CPI" />
      <net name="TMC_VCP" />
      <net name="TMC_5VOUT" isPowerNet />
      <net name="TMC_VREF" />
      <net name="TMC_SENSE_A" />
      <net name="TMC_SENSE_B" />
      <net name="MOTOR_A1" />
      <net name="MOTOR_A2" />
      <net name="MOTOR_B1" />
      <net name="MOTOR_B2" />
      <McuSheet />
      <EncoderSheet />
      <CanSheet />
      <LogicBuckSheet />
      <MotorDriverSheet />
    </board>
  )
}
