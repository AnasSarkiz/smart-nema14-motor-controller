# Phidgets 3323_0 motor-mounted diagnostic assembly

Revision 0.0.8-alpha.0, 2026-10-03 Europe/Tirane. **Mechanics blocked;
routing disabled; not fabrication ready.** This file supersedes the earlier
unknown-motor requirement. It does not pass a complete-board validation stage.

## Authoritative motor and encoder sources

- [Phidgets 3323_0 product](https://www.phidgets.com/?prodid=342), model
  35STH40-1004B. 1 A/phase, 2.7 ohm, 4.3 mH; the earlier 1.2 A target is
  retired. Proposed firmware limits require RMS/peak and thermal qualification.
- [Official drawing 0DZ.252.001](https://www.phidgets.com/productfiles/3323/3323_0/Documentation/3323_0_Mechanical.pdf),
  retained unchanged in references/motor/3323_0_Mechanical.pdf and visually
  inspected after rendering. Rear view is used, wires toward -Y.
- [Official STEP ZIP](https://www.phidgets.com/productfiles/3323/3323_0/Images/3323_0_3D.zip),
  retained unchanged; its single 3323_0.stp is extracted byte-for-byte.
  OpenCASCADE imports centimetre STEP source units into millimetres.
- AMS AS5600 datasheet v1-02, 2015-Nov-13, from the
  [official component supplier](https://datasheet.lcsc.com/datasheet/pdf/fab02cf30a2c48b5aeeebf03db9fe675.pdf?productCode=C79815).
  Original manufacturer URL returned 404 and no replacement datasheet is
  invented. Reviewed rendered pp. 33-35: package-centered Hall array, 6 mm
  magnet displacement guidance of 0.25 mm, typical 0.5-3 mm air gap,
  SOIC8 dimensions and AGC qualification requirement.

## Exact geometry lock and model findings

| Feature | Official drawing / requirement | Original STEP measurement |
| --- | --- | --- |
| Rear shaft diameter | 3.9 +0/-0.15 mm | **4.0 mm: discrepancy, B014** |
| Rear shaft projection | 12 +0.7/-0.3 mm | 12 mm nominal |
| Rear mounting | 2 x M1.6 through PCB, circle 14.5 +/-0.15 mm | 14.5 mm, modeled minor bores 1.221 mm |
| Rear hole line | 40 degrees from +X in rear view | 40 degrees |
| Screw depth into motor | Strictly below 2.5 mm | Proposed male stud 2.0 +/-0.1 mm; maximum 2.1 mm |
| Motor body | 35.2 mm maximum, 40 mm axial length | 34.95 x 34.95 x 40 mm |
| Front features | 4 x M3 / 26 mm; excluded from PCB rear mounting | Retained only in the original motor model |

Native PCB rear hole centers are exactly +/-(5.553822212612591,
4.660210170227409) mm. Clearance-hole diameter 2.2 mm is a proposal,
not a 2.2 mm thread or altered motor hole. AS5600 native center and magnet
axis are (0,0), bottom sensor faces the magnet. Native CAD retains the
importer's model origin; its encoder origin rounding is 0.0000127 mm.
Nominal centering does not establish physical assembly alignment.

World origin is the PCB mid-plane. PCB is 35 x 35 x 1.6 mm. Motor rear
face is Z=-19.1 mm; original model rear-plane datum (-17.475,17.475,0)
is translated and rotated 180 degrees about X. Motor body extends toward
-Z and rear shaft points toward the PCB. No generic motor geometry or
manually edited original STEP is used.

## Proposed mechanical hardware — not sourced or approved

Generated CAD describes mechanical envelopes only, not electronic component
definitions. All electronic definitions and their CAD metadata remain the
unchanged official supplier/package outputs.

- Nonmagnetic standoffs: 18.3 +/-0.05 mm long, outside diameter 3.2 mm,
  M1.6 male projection 2.0 +/-0.1 mm, top female threaded envelope. Model
  includes proposed 4 mm top screw, 0.3 mm washer and 3.2 mm head envelope.
  Threads are major/minor clearance envelopes, not detailed thread profiles.
  Major-thread overlap with the motor's minor bore is an intentional modeled
  thread-engagement exception; procurement, torque and vibration remain open.
- Nonmagnetic retaining cup: 4.05 mm bore, 8 mm outside diameter, 0.3 mm
  floor, proposed adhesive/jig alignment. The loose bore is not a centered
  press fit. Retention, runout, shaft/motor discrepancy, material, temperature
  and manufacturing tolerances require qualification.
- Diametrically magnetized 6 x 2.5 mm magnet envelope. Exact magnet supply,
  magnetization/field and tolerances are not qualified; no candidate is
  presented as a purchased approved part.

Measured nominal magnet-to-package surface gap: 1.8 mm. Conditional stack
range: 0.8-2.7 mm, using 11.7-12.7 mm shaft projection, proposed floor
0.2-0.4 mm, proposed magnet height 2.4-2.6 mm, standoff 18.25-18.35 mm,
package A maximum 1.75 mm and A2 minimum 1.25 plus A1 minimum 0.10 mm.
This excludes solder height, retention, axial end-play not specified by the
drawing, thermal movement and magnetic qualification. The typical data-sheet
gap range is not an operating guarantee. Check AGC/field and angle performance
on a physical prototype.

The 2.2 mm PCB holes around M1.6 fasteners permit 0.3 mm radial movement,
already larger than the 0.25 mm magnet-axis allowance before adding placement,
motor-hole and magnet-runout tolerances. An axis registration/jig process and
qualified hardware tolerances are required; CAD nominal coordinates alone
do not pass this requirement (B003).

## Actual assembly and visual review

assembly.circuit.tsx uses native assembly.device / assembly.subassembly /
cadmodel APIs from installed core 0.0.2052 / props 0.0.676, verified in local
source and [official documentation](https://docs.tscircuit.com/elements/assembly-subassembly).
It reuses all 56 actual draft supplier components, adds unchanged official
C136657 programmer connector as a separate mechanical envelope and native
rear holes. Programmer VOUT is deliberately unconnected in the fixture;
functional power integration remains unresolved in the main design.

Only the diagnostic view uses these provisional coordinates. This is not an
approved high-current/decoupling/routing layout. Motor, CAN, STEP/DIR and
limit connectors and their mating cables are not selected and cannot be
qualified or shown as completed geometry. USB/C136657 models are present;
full cable/mating access remains unqualified. The programming connector was
rotated toward the right edge after an insertion-direction warning.

Current native PCB PNG, 3D PNG, GLB and interactive viewer were inspected.
Whole, motor-front, rear-stack, side and transparent-board encoder views are preserved
as viewer-*.png in revision 0.0.8 evidence. The viewer uses the actual current
native GLB, with no substituted electronics. Its transparency control was
fixed for the GLB's PCB group, then visually retested; no additional console
error occurred after that repair. It is an offline standalone HTML file.

The user's comparison image identifies HOLRY NEMA14 (35HBSG), a lead-screw
motor with 27/34 mm body lengths. That is a different model from the locked
Phidgets 3323_0 / 35STH40-1004B. NEMA 14 frame size alone does not establish
interchangeable rear geometry. The viewer now exposes the original motor front
and links directly to the official Phidgets ZIP. ZIP-member bytes match the
local STEP exactly; its plain appearance is the original simplified vendor CAD.
Download identity is confirmed; the 4.0/3.9 mm discrepancy still blocks fit approval.

Previous CadQuery inspection renders under previous-jst-orientation/ use
the earlier programmer orientation and are explicitly historical. Exact
measurements and assembly STEP were regenerated after the final connector
rotation; the current native viewer supplies the latest visual review.

## Collision evidence and remaining gates

The exact CAD checker imports all 29 distinct official supplier STEP URLs
for 57 components, and checks their actual circuit-JSON placement alongside
the original motor, PCB and proposed hardware. It reports 62 shape groups.
All pairwise positive-volume intersections and critical distances are saved
in ASSEMBLY-GEOMETRY-CHECK.json, linked to the native circuit SHA-256.

Unresolved USB C165948 model / PCB intersection: **0.358309 mm3**, B015.
Determine model/land/native placement registration before approving fit.
No hand-edited footprint or CAD compensation is allowed. Model contacts at
zero distance to the PCB are not positive-volume collisions. The intentional
modeled motor thread engagement is separately identified.

Measured nominal clearances include AS5600 to standoffs 2.223104 mm,
cup to standoffs 1.65 mm, magnet to standoffs 2.65 mm, magnet to PCB
3.5 mm, and AS5600 to unchanged STEP rear shaft tip 4.6 mm. These are
nominal CAD distances, not fully toleranced manufacturer acceptance.

Official native assembly build: zero generated error elements, no traces or
vias. Official placement DRC reports zero errors/warnings, after the seven actionable
orientation suggestions were fixed through native instance pcbRotation props.
This remains a diagnostic fixture, not qualification of the future routed layout. Existing imported symbol
and power/ground metadata warnings remain visible; none is suppressed or
accepted for fabrication. Functional schematic/BOM blockers remain.

**Mechanics has not passed.** Per the user's sequence, the next manufacturer
USB footprint audit remains gated. The existing B011 HRO/GCT land-pattern
discrepancies remain valid and neither connector is qualified for fabrication.
There is no routed copper, fabrication package, prototype test or order.
