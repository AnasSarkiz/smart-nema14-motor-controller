"""Propose local native source bends; not a board validation or routing result."""
import json,math,heapq,time
from pathlib import Path
import numpy as np
import shapely
from shapely.geometry import LineString,Point,box
from shapely.ops import unary_union
j=json.load(open('dist/index/circuit.json'));source=json.load(open('src/routing/power-guarded-paths-trial.json'));parent={}
def root(k):
 parent.setdefault(k,k)
 if parent[k]!=k:parent[k]=root(parent[k])
 return parent[k]
for t in j:
 if t['type']=='source_trace':
  ids=t['connected_source_port_ids']+t['connected_source_net_ids']
  for k in ids[1:]:parent[root(k)]=root(ids[0])
netnames={root(e['source_net_id']):e['name'] for e in j if e['type']=='source_net'}
traces={e['source_trace_id']:e for e in j if e['type']=='source_trace'}
conductors=[]
for t in j:
 if t['type']!='pcb_trace':continue
 net=netnames.get(root(traces[t['source_trace_id']]['connected_source_port_ids'][0]),'unnamed')
 if net.startswith('MOTOR_'):continue
 route=t['route'];layer=route[0].get('layer','top')
 for a,b in zip(route,route[1:]):
  layer=a.get('layer',a.get('to_layer',layer))
  if (a['x'],a['y'])!=(b['x'],b['y']):conductors.append((net,layer,LineString([(a['x'],a['y']),(b['x'],b['y'])]).buffer(a.get('width',b.get('width',.15))/2,quad_segs=16)))
for e in j:
 if e['type']=='pcb_via':
  key=e.get('source_net_id')
  if not key:
   tid=e.get('source_trace_id') or next(t['source_trace_id'] for t in j if t['type']=='pcb_trace' and t['pcb_trace_id']==e['pcb_trace_id'])
   key=traces[tid]['connected_source_port_ids'][0]
  net=netnames.get(root(key),'unnamed')
  for layer in e['layers']:conductors.append((net,layer,Point(e['x'],e['y']).buffer(e['outer_diameter']/2,quad_segs=32)))
indices={135:'MOTOR_B2',133:'MOTOR_A1',123:'MOTOR_B1',134:'MOTOR_A2'}
# Source selectors/phase identities are asserted against the emitted pin net partitions.
refs={e['source_component_id']:e['name'] for e in j if e['type']=='source_component'}
ports={e['source_port_id']:e for e in j if e['type']=='source_port'}
for i,net in indices.items():
 pin=int(source['paths'][i]['connection'].split('pin')[1]);p=next(e for e in ports.values() if refs.get(e['source_component_id'])=='J_MOTOR' and f'pin{pin}' in e['port_hints']);assert netnames[root(p['source_port_id'])]==net
for i,net in indices.items():
 for a,b in zip(source['paths'][i]['route'],source['paths'][i]['route'][1:]):
  if a['route_type']=='wire' and a.get('layer','').startswith('inner') and (a['x'],a['y'])!=(b['x'],b['y']):conductors.append((net,a['layer'],LineString([(a['x'],a['y']),(b['x'],b['y'])]).buffer(.25/2,quad_segs=32)))

def propose(original,obstacle,corridor_mm):
 start,end=original[0],original[-1];line=LineString(original)
 allowed=line.buffer(corridor_mm,quad_segs=8).intersection(box(-17.04,-17.04,17.04,17.04))
 if obstacle.intersects(Point(start)) or obstacle.intersects(Point(end)):return None
 if not obstacle.intersects(line):return original
 step=.01;x0,y0,x1,y1=allowed.bounds;nx=math.ceil((x1-x0)/step)+1;ny=math.ceil((y1-y0)/step)+1
 xs=x0+np.arange(nx)*step;ys=y0+np.arange(ny)*step;xx,yy=np.meshgrid(xs,ys);shapely.prepare(obstacle);shapely.prepare(allowed)
 free=shapely.contains_xy(allowed,xx,yy)&~shapely.contains_xy(obstacle,xx,yy)
 def nearby(p):
  ix=round((p[0]-x0)/step);iy=round((p[1]-y0)/step);out={}
  for dy in range(-3,4):
   for dx in range(-3,4):
    x,y=ix+dx,iy+dy
    if 0<=x<nx and 0<=y<ny and free[y,x] and not obstacle.intersects(LineString([p,(xs[x],ys[y])])):out[y*nx+x]=math.dist(p,(xs[x],ys[y]))
  return out
 starts=nearby(start);ends=nearby(end)
 if not starts or not ends:return None
 queue=[];cost={};prev={}
 for k,c in starts.items():cost[k]=c;prev[k]=None;heapq.heappush(queue,(c+math.dist((xs[k%nx],ys[k//nx]),end),c,k))
 goal=None
 while queue:
  _,c,k=heapq.heappop(queue)
  if c>cost[k]+1e-12:continue
  if k in ends:goal=k;break
  y,x=divmod(k,nx)
  for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
   u,v=x+dx,y+dy
   if not(0<=u<nx and 0<=v<ny and free[v,u]):continue
   if dx and dy and (not free[y,u] or not free[v,x]):continue
   n=v*nx+u;nc=c+step*math.hypot(dx,dy)
   if nc<cost.get(n,math.inf):cost[n]=nc;prev[n]=k;heapq.heappush(queue,(nc+math.dist((xs[u],ys[v]),end),nc,n))
 if goal is None:return None
 pts=[];k=goal
 while k is not None:pts.append((float(xs[k%nx]),float(ys[k//nx])));k=prev[k]
 pts=[start,*pts[::-1],end];simple=[pts[0]];a=0
 while a<len(pts)-1:
  b=len(pts)-1
  while b>a+1 and obstacle.intersects(LineString([pts[a],pts[b]])):b-=1
  if obstacle.intersects(LineString([pts[a],pts[b]])):return None
  if pts[b]!=simple[-1]:simple.append(pts[b])
  a=b
 assert not obstacle.intersects(LineString(simple))
 return simple

results=[]
for i,net in indices.items():
 path=source['paths'][i];r=path['route'];chunks=[];k=0
 while k<len(r):
  if r[k].get('layer','').startswith('inner'):
   end=k
   while end+1<len(r) and r[end+1].get('layer')==r[k]['layer']:end+=1
   chunks.append((k,end));k=end+1
  else:k+=1
 for a,b in reversed(chunks):
  layer=r[a]['layer'];original=[(q['x'],q['y']) for q in r[a:b+1]]
  if len(set(original))<2:continue
  obstacle=unary_union([shape.buffer(.15+.135+.001,quad_segs=24) for owner,ly,shape in conductors if ly==layer and owner!=net])
  proposed=None
  for corridor in [.3,.6,1.0,2.0]:
   proposed=propose(original,obstacle,corridor)
   if proposed is not None:break
  if proposed is None:
   print('Blocked endpoints', [(p,obstacle.intersects(Point(p))) for p in (original[0],original[-1])],flush=True)
   print('Nearest foreign', sorted([(Point(original[0]).distance(shape),owner,ly,shape.bounds) for owner,ly,shape in conductors if ly==layer and owner!=net])[:5],flush=True)
   raise RuntimeError(f'No preserved-via local corridor: {net} {layer} {a}:{b}')
  results.append({'path_index':i,'net':net,'layer':layer,'original':original,'proposed':proposed,'width_mm':.27,'corridor_mm':corridor,'new_vias':0})
  r[a:b+1]=[{'route_type':'wire','x':x,'y':y,'layer':layer,'width':.27} for x,y in proposed]
  # Replace the corresponding foreign-net obstacle before planning another winding.
  old=LineString(original).buffer(.135,quad_segs=32)
  conductors=[(owner,ly,shape) for owner,ly,shape in conductors if not(owner==net and ly==layer and old.buffer(.00001).covers(shape))]
  conductors.append((net,layer,LineString(proposed).buffer(.135,quad_segs=32)))
  print(net,layer,len(original),'->',len(proposed),'points',flush=True)
Path('.publication/fix36/motor-source-candidate.json').write_text(json.dumps(source,indent=2)+'\n')
Path('.publication/fix36/motor-corridor-candidates.json').write_text(json.dumps(results,indent=2)+'\n')
