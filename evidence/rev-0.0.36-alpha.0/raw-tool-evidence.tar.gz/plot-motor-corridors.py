from pathlib import Path
exec(compile(Path('.publication/fix36/plan-motor-corridors-027-a2first.py').read_text().split('results=[]')[0],'<manual-proposal-geometry>','exec'))
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch
region=box(-11,3,-.5,9.5);fig,ax=plt.subplots(figsize=(16,10));palette=plt.get_cmap('tab20');colors={}
for net,layer,shape in conductors:
 if layer!='inner2' or not shape.intersects(region):continue
 colors.setdefault(net,palette(len(colors)%20));geom=shape.intersection(region)
 for g in geom.geoms if hasattr(geom,'geoms') else [geom]:
  if g.geom_type!='Polygon':continue
  ax.add_patch(Patch(list(g.exterior.coords),facecolor=colors[net],edgecolor='black',lw=.3,alpha=.75))
  if g.area>.09:
   p=g.representative_point();ax.text(p.x,p.y,net,fontsize=7,ha='center',clip_on=True)
for e in j:
 if e['type']=='pcb_via' and region.contains(Point(e['x'],e['y'])):ax.text(e['x'],e['y']+.12,e['pcb_via_id'].replace('pcb_via_','v'),fontsize=6,ha='center')
ax.set(xlim=(-11,-.5),ylim=(3,9.5),aspect='equal');ax.grid(alpha=.3);fig.savefig('.publication/fix36/motor-inner2-corridor.png',dpi=120)
