import json,runpy
from pathlib import Path
from pygerber.gerberx3.api.v2 import GerberFile,OnParserErrorEnum
from shapely import affinity
from shapely.geometry import box
read_svg=runpy.run_path('scripts/read-gerber-svg.py')['read_gerber_svg'];out=Path('.publication/fix36/native-cam-corrected');layers={};results=[]
for name in ['F_SilkScreen.gbr','B_SilkScreen.gbr','F_Mask.gbr','B_Mask.gbr']:
 if not (out/name).exists(): print('missing',name);continue
 parsed=GerberFile.from_file(out/name).parse(on_parser_error=OnParserErrorEnum.Raise);bounds=parsed.get_info();target=out/(name+'.svg');parsed.render_svg(target);shape=read_svg(target);shape=affinity.scale(shape,yfact=-1,origin=(0,0));shape=affinity.translate(shape,float(bounds.min_x_mm),float(bounds.max_y_mm));layers[name]=shape
for silk,mask in [('F_SilkScreen.gbr','F_Mask.gbr'),('B_SilkScreen.gbr','B_Mask.gbr')]:
 if silk not in layers:continue
 s,m=layers[silk],layers[mask];bad=s.intersection(m.buffer(.15));outside=s.difference(box(-17.5,-17.5,17.5,17.5));results.append({'layer':silk,'mask_clearance_mm':s.distance(m),'silk_within_0_15mm_mask_clearance_mm2':bad.area,'silk_outside_outline_mm2':outside.area})
j=json.load(open('dist/index/circuit.json'));thin=[{'id':e.get('pcb_silkscreen_path_id'),'pcb_component_id':e.get('pcb_component_id'),'stroke_width_mm':e.get('stroke_width')} for e in j if e['type']=='pcb_silkscreen_path' and e.get('stroke_width',0)<.15]
report={'scope':'Direct native Gerber silk and mask vector geometry, manufacturer 0.15mm mask clearance. Supplier paths are unchanged; result is diagnostic and does not authorize footprint edits.','layers':results,'native_supplier_paths_below_0_15mm':thin,'passed':not thin and all(r['silk_within_0_15mm_mask_clearance_mm2']==0 and r['silk_outside_outline_mm2']==0 for r in results)};Path('evidence/rev-0.0.36-alpha.0/SILKSCREEN-CAM.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'layers':results,'thin_paths':len(thin),'passed':report['passed']}))
