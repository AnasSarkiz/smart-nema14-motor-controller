"""Independent strict Gerber parser and vector geometry comparison."""
import json,sys,runpy,hashlib,zipfile
from pathlib import Path
from shapely import affinity
from shapely.ops import unary_union
from shapely.geometry import Point
from pygerber.gerberx3.api.v2 import GerberFile,OnParserErrorEnum,ColorScheme
circuit_path=Path('.publication/fix36/canonical-cam-08.json');out=Path('.publication/fix36/cam-08');out.mkdir(exist_ok=True)
with zipfile.ZipFile('.publication/fix36/native-cam-08.zip') as z:z.extractall(out)
read_svg=runpy.run_path('scripts/read-gerber-svg.py')['read_gerber_svg']
sys.argv=['scripts/check-filled-copper.py',str(circuit_path),'.publication/fix36/cam-source-geometry.json']
g=runpy.run_path('scripts/check-filled-copper.py',run_name='gerber_source_geometry')
circuit=g['circuit'];drills=unary_union([Point(e['x'],e['y']).buffer(e['hole_diameter']/2,quad_segs=128) for e in circuit if e['type'] in ['pcb_via','pcb_hole']]);report=[]
for filename,layer in [('F_Cu.gbr','top'),('In1_Cu.gbr','inner1'),('In2_Cu.gbr','inner2'),('B_Cu.gbr','bottom')]:
 p=GerberFile.from_file(out/filename).parse(on_parser_error=OnParserErrorEnum.Raise);bounds=p.get_info();p.render_svg(out/(filename+'.svg'))
 diagnostics={};actual=read_svg(out/(filename+'.svg'),diagnostics);actual=affinity.scale(actual,xfact=1,yfact=-1,origin=(0,0));actual=affinity.translate(actual,float(bounds.min_x_mm),float(bounds.max_y_mm));actual=actual.difference(drills)
 expected=unary_union([e['shape'] for e in g['conductors'] if e['layer']==layer]).difference(drills)
 missing=expected.difference(actual.buffer(.000002));extra=actual.difference(expected.buffer(.000002))
 netloss=[]
 for key,net in g['net_names'].items():
  copper=unary_union([e['shape'] for e in g['conductors'] if e['layer']==layer and e['net']==key]).difference(drills);loss=copper.intersection(missing)
  if loss.area>1e-9:netloss.append({'net':net,'missing_mm2':loss.area,'bounds_mm':list(loss.bounds)})
 r={'file':filename,'layer':layer,'svg_diagnostics':diagnostics,'source_sha256':hashlib.sha256((out/filename).read_bytes()).hexdigest(),'expected_mm2':expected.area,'actual_mm2':actual.area,'missing_mm2_after_2um_coordinate_allowance':missing.area,'extra_mm2_after_2um_coordinate_allowance':extra.area,'net_losses':netloss};report.append(r);print(json.dumps(r),flush=True)
 (out/(filename+'.wkt')).write_text(actual.wkt)
Path('.publication/fix36/CAM-COPPER-COMPARISON.json').write_text(json.dumps({'canonical_sha256':hashlib.sha256(circuit_path.read_bytes()).hexdigest(),'parser':'PyGerber 2.4.3; OnParserErrorEnum.Raise; vector geometry including ordered dark/clear masks','scope':'Actual four copper layers against the canonical native filled copper, component pads, trace widths and via annuli. Exact drill hits excluded in both geometric sets. 2um boundary allowance for recorded coordinate/curve serialization, not a change to board DRC rules.','layers':report},indent=2)+'\n')
