import assert from "node:assert/strict"
import { readFileSync } from "node:fs"

// Independent physical-pin checks against the manufacturer pin tables.
// This qualifies only the implemented draft blocks, never the complete board.
const circuitJson = JSON.parse(readFileSync("dist/index/circuit.json", "utf8"))
const components = circuitJson.filter(
  (element) => element.type === "source_component",
)
const ports = circuitJson.filter((element) => element.type === "source_port")
const nets = circuitJson.filter((element) => element.type === "source_net")
const traces = circuitJson.filter((element) => element.type === "source_trace")

function checkPinNet(pinReference, expectedNetName) {
  const component = components.find(
    (candidate) => candidate.name === pinReference.ref,
  )
  assert.ok(component, `Missing ${pinReference.ref}`)
  const port = ports.find(
    (candidate) =>
      candidate.source_component_id === component.source_component_id &&
      candidate.pin_number === pinReference.pin,
  )
  assert.ok(
    port,
    `Missing ${pinReference.ref} physical pin ${pinReference.pin}`,
  )
  const connectedNetIds = traces
    .filter((trace) =>
      trace.connected_source_port_ids.includes(port.source_port_id),
    )
    .flatMap((trace) => trace.connected_source_net_ids)
  const connectedNetNames = nets
    .filter((net) => connectedNetIds.includes(net.source_net_id))
    .map((net) => net.name)
  assert.deepEqual(
    [...new Set(connectedNetNames)],
    [expectedNetName],
    `${pinReference.ref} physical pin ${pinReference.pin}`,
  )
}

for (const [ref, pin, net] of [
  ["U1", 4, "V3V3"],
  ["U1", 5, "V3V3"],
  ["U1", 6, "V3V3"],
  ["U1", 7, "GND"],
  ["U1", 10, "NRST"],
  ["U1", 44, "CAN_RX"],
  ["U1", 45, "CAN_TX"],
  ["U1", 47, "I2C_SCL"],
  ["U1", 48, "I2C_SDA"],
  ["U4", 1, "V3V3"],
  ["U4", 2, "V3V3"],
  ["U4", 4, "GND"],
  ["U4", 6, "I2C_SDA"],
  ["U4", 7, "I2C_SCL"],
  ["U4", 8, "GND"],
  ["U6", 1, "CAN_TX"],
  ["U6", 2, "GND"],
  ["U6", 3, "V3V3"],
  ["U6", 4, "CAN_RX"],
  ["U6", 6, "CAN_L"],
  ["U6", 7, "CAN_H"],
  ["U6", 8, "GND"],
  ["U1", 13, "TMC_UART_TX"],
  ["U1", 14, "TMC_UART_RX"],
  ["U1", 15, "TMC_ENABLE_N"],
  ["U1", 16, "TMC_DIAG"],
  ["U1", 17, "TMC_STEP"],
  ["U1", 18, "TMC_DIR"],
  ["U5", 1, "V3V3"],
  ["U5", 2, "VBUS_INRUSH_OUT"],
  ["U5", 3, "VBUS_INRUSH_OUT"],
  ["U5", 4, "GND"],
  ["U5", 5, "BUCK_SW"],
  ["U5", 6, "BUCK_BST"],
  ["U2", 1, "MOTOR_B2"],
  ["U2", 2, "TMC_ENABLE_N"],
  ["U2", 3, "GND"],
  ["U2", 4, "TMC_CPO"],
  ["U2", 5, "TMC_CPI"],
  ["U2", 6, "TMC_VCP"],
  ["U2", 7, "GND"],
  ["U2", 8, "TMC_5VOUT"],
  ["U2", 9, "GND"],
  ["U2", 10, "GND"],
  ["U2", 11, "TMC_DIAG"],
  ["U2", 13, "GND"],
  ["U2", 14, "TMC_UART_RX"],
  ["U2", 15, "V3V3"],
  ["U2", 16, "TMC_STEP"],
  ["U2", 17, "TMC_VREF"],
  ["U2", 18, "GND"],
  ["U2", 19, "TMC_DIR"],
  ["U2", 20, "GND"],
  ["U2", 21, "MOTOR_A2"],
  ["U2", 22, "VM"],
  ["U2", 23, "TMC_SENSE_A"],
  ["U2", 24, "MOTOR_A1"],
  ["U2", 25, "GND"],
  ["U2", 26, "MOTOR_B1"],
  ["U2", 27, "TMC_SENSE_B"],
  ["U2", 28, "VM"],
  ["U2", 29, "GND"],
  ["L1", 1, "BUCK_SW"],
  ["L1", 2, "V3V3"],
  ["C10", 1, "BUCK_BST"],
  ["C10", 2, "BUCK_SW"],
  ["C13", 1, "TMC_CPO"],
  ["C13", 2, "TMC_CPI"],
  ["C14", 1, "TMC_VCP"],
  ["C14", 2, "VM"],
  ["C19", 1, "VM"],
  ["C19", 2, "GND"],
  ["C20", 1, "VM"],
  ["C20", 2, "GND"],
  ["R4", 1, "TMC_UART_TX"],
  ["R4", 2, "TMC_UART_RX"],
  ["R5", 1, "TMC_SENSE_A"],
  ["R5", 2, "GND"],
  ["R6", 1, "TMC_SENSE_B"],
  ["R6", 2, "GND"],
  ["R7", 1, "V3V3"],
  ["R7", 2, "TMC_ENABLE_N"],
  ["R10", 1, "TMC_5VOUT"],
  ["R10", 2, "TMC_VREF"],
  ["R11", 1, "TMC_VREF"],
  ["R11", 2, "GND"],
])
  checkPinNet({ ref, pin }, net)

assert.equal(
  components.length,
  38,
  "Do not validate an empty or unexpected draft",
)
assert.ok(
  components.every(
    (component) => component.supplier_part_numbers?.jlcpcb?.length > 0,
  ),
  "Every instantiated part must carry a JLCPCB supplier number",
)
const sheets = circuitJson.filter(
  (element) => element.type === "schematic_sheet",
)
assert.equal(sheets.length, 5)
assert.ok(
  sheets.every(
    (sheet) =>
      sheet.sheet_size === "a4" &&
      sheet.sheet_width === 297 &&
      sheet.sheet_height === 210,
  ),
)
const powerNet = nets.find((net) => net.name === "V3V3")
const groundNet = nets.find((net) => net.name === "GND")
assert.notEqual(
  powerNet.subcircuit_connectivity_map_key,
  groundNet.subcircuit_connectivity_map_key,
  "Power and ground must be separate connectivity groups",
)
const distinctPowerNets = [
  "GND",
  "V3V3",
  "VM",
  "TMC_5VOUT",
  "VBUS_INRUSH_OUT",
].map((netName) => {
  const net = nets.find((candidate) => candidate.name === netName)
  assert.ok(net, `Missing ${netName}`)
  return net.subcircuit_connectivity_map_key
})
assert.equal(
  new Set(distinctPowerNets).size,
  distinctPowerNets.length,
  "Different supply rails must never be shorted together",
)
for (const ref of ["R5", "R6"]) {
  const resistor = components.find((component) => component.name === ref)
  assert.equal(resistor.ftype, "simple_resistor")
  assert.equal(resistor.resistance, 0.2, `${ref} sense resistance`)
  assert.deepEqual(resistor.supplier_part_numbers.jlcpcb, ["C723709"])
}
for (const ref of ["C19", "C20"]) {
  const capacitor = components.find((component) => component.name === ref)
  assert.equal(capacitor.capacitance, 100e-6, `${ref} motor bulk`)
  assert.equal(
    capacitor.are_pins_interchangeable,
    false,
    `${ref} must stay polarized`,
  )
}
assert.equal(
  components.find((component) => component.name === "C13").capacitance,
  22e-9,
  "Charge-pump flying capacitor must be 22 nF",
)
assert.equal(
  components.find((component) => component.name === "L1").inductance,
  "4.7uH",
  "Buck inductor must match the reviewed ripple calculation",
)
assert.equal(
  circuitJson.filter((element) => element.type.startsWith("pcb_")).length,
  0,
  "Draft evidence must be generated with --disable-pcb; placement awaits mechanics",
)
assert.equal(
  circuitJson.filter((element) => element.type.endsWith("_error")).length,
  0,
)
console.log(
  "Draft checks passed: 86 physical-pin connections, 38 supplier parts, five A4 sheets, separate power/ground, no PCB output.",
)
