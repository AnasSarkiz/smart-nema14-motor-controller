import { CanSheet } from "./src/can/CanSheet"
import { EncoderSheet } from "./src/encoder/EncoderSheet"
import { McuSheet } from "./src/mcu/McuSheet"

/** Schematic development only. Mechanics and full circuit review gate placement. */
export default function SmartNema14MotorController() {
  return (
    <board
      width="35mm"
      height="35mm"
      layers={4}
      routingDisabled
      schLayout={{ layoutMode: "none" }}
    >
      <net name="GND" isGroundNet />
      <net name="V3V3" isPowerNet />
      <net name="NRST" />
      <net name="I2C_SCL" />
      <net name="I2C_SDA" />
      <net name="CAN_TX" />
      <net name="CAN_RX" />
      <net name="CAN_H" />
      <net name="CAN_L" />
      <McuSheet />
      <EncoderSheet />
      <CanSheet />
    </board>
  )
}
