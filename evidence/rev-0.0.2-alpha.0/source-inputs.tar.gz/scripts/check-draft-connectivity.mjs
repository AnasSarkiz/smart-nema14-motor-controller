import assert from "node:assert/strict"
import { readFileSync } from "node:fs"

// Independent physical-pin checks against the manufacturer pin tables.
// This qualifies only the implemented draft blocks, never the complete board.
const circuitJson = JSON.parse(readFileSync("dist/index/circuit.json", "utf8"))
const components = circuitJson.filter(
  (element) => element.type === "source_component",
)
const ports = circuitJson.filter((element) => element.type === "source_port")
const nets = circuitJson.filter((element) => element.type === "source_net")
const traces = circuitJson.filter((element) => element.type === "source_trace")

function checkPinNet(pinReference, expectedNetName) {
  const component = components.find(
    (candidate) => candidate.name === pinReference.ref,
  )
  assert.ok(component, `Missing ${pinReference.ref}`)
  const port = ports.find(
    (candidate) =>
      candidate.source_component_id === component.source_component_id &&
      candidate.pin_number === pinReference.pin,
  )
  assert.ok(
    port,
    `Missing ${pinReference.ref} physical pin ${pinReference.pin}`,
  )
  const connectedNetIds = traces
    .filter((trace) =>
      trace.connected_source_port_ids.includes(port.source_port_id),
    )
    .flatMap((trace) => trace.connected_source_net_ids)
  const connectedNetNames = nets
    .filter((net) => connectedNetIds.includes(net.source_net_id))
    .map((net) => net.name)
  assert.deepEqual(
    [...new Set(connectedNetNames)],
    [expectedNetName],
    `${pinReference.ref} physical pin ${pinReference.pin}`,
  )
}

for (const [ref, pin, net] of [
  ["U1", 4, "V3V3"],
  ["U1", 5, "V3V3"],
  ["U1", 6, "V3V3"],
  ["U1", 7, "GND"],
  ["U1", 10, "NRST"],
  ["U1", 44, "CAN_RX"],
  ["U1", 45, "CAN_TX"],
  ["U1", 47, "I2C_SCL"],
  ["U1", 48, "I2C_SDA"],
  ["U4", 1, "V3V3"],
  ["U4", 2, "V3V3"],
  ["U4", 4, "GND"],
  ["U4", 6, "I2C_SDA"],
  ["U4", 7, "I2C_SCL"],
  ["U4", 8, "GND"],
  ["U6", 1, "CAN_TX"],
  ["U6", 2, "GND"],
  ["U6", 3, "V3V3"],
  ["U6", 4, "CAN_RX"],
  ["U6", 6, "CAN_L"],
  ["U6", 7, "CAN_H"],
  ["U6", 8, "GND"],
])
  checkPinNet({ ref, pin }, net)

assert.equal(
  components.length,
  13,
  "Do not validate an empty or unexpected draft",
)
assert.ok(
  components.every(
    (component) => component.supplier_part_numbers?.jlcpcb?.length > 0,
  ),
  "Every instantiated part must carry a JLCPCB supplier number",
)
const sheets = circuitJson.filter(
  (element) => element.type === "schematic_sheet",
)
assert.equal(sheets.length, 3)
assert.ok(
  sheets.every(
    (sheet) =>
      sheet.sheet_size === "a4" &&
      sheet.sheet_width === 297 &&
      sheet.sheet_height === 210,
  ),
)
const powerNet = nets.find((net) => net.name === "V3V3")
const groundNet = nets.find((net) => net.name === "GND")
assert.notEqual(
  powerNet.subcircuit_connectivity_map_key,
  groundNet.subcircuit_connectivity_map_key,
  "Power and ground must be separate connectivity groups",
)
assert.equal(
  circuitJson.filter((element) => element.type.startsWith("pcb_")).length,
  0,
  "Draft evidence must be generated with --disable-pcb; placement awaits mechanics",
)
assert.equal(
  circuitJson.filter((element) => element.type.endsWith("_error")).length,
  0,
)
console.log(
  "Draft checks passed: 22 physical-pin connections, 13 supplier parts, three A4 sheets, separate power/ground, no PCB output.",
)
