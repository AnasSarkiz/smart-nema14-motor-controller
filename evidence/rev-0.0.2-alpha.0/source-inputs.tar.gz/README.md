# Smart NEMA 14 Motor Controller

Revision `0.0.2-alpha.0`, reviewed 2026-10-02. **Schematic draft; not fabrication ready.**

Standalone USB-C PD stepper controller targeting a 35 x 35 mm four-layer PCB:
STM32G0B1, TMC2209, bottom-side AS5600, classical CAN, STEP/DIR, two limits,
temperature monitoring and the official Standard JST SWD + Reset connector.

Read [VALIDATION.md](VALIDATION.md), [issues.md](issues.md),
[ARCHITECTURE.md](ARCHITECTURE.md), [BOM.md](BOM.md) and
[references/MCU-PIN-PLAN.md](references/MCU-PIN-PLAN.md).
The supplied brief is preserved in [references/USER-BRIEF.md](references/USER-BRIEF.md).

## Current contents

- Global tscircuit updated from 0.0.2696 to 0.0.2729.
- C2847904 and C1121848 regenerated directly using released `easyeda@0.0.360`.
  The unchanged critical-label audit passes. Neither definition was manually patched.
- `src/`: three native A4 sheets for MCU core, optional AS5600 and classical CAN.
  These instantiate 13 supplier parts. Other circuitry is explicitly unfinished.
- `imports/`: generated JLCPCB components; new supplier JSON and prior imports
  retained under `evidence/rev-0.0.2-alpha.0/`.
- Official `@tsci/tscircuit.standard-jst-programmer@0.8.0` installed; integration pending.
- `dist/index/schematic-MCU.svg`, `schematic-Encoder.svg`, `schematic-CAN.svg`
  and corresponding PNGs: reviewed draft sheets.
- No validated PCB placement, mounting holes, shaft clearance, copper or fabrication package.

This task has its own local Git repository, no source commit or remote.
Versioned manifests and source archives identify the reviewed inputs.

## Commands

Run from this board directory:

```sh
bun install --frozen-lockfile
bun run format:check
bun run typecheck
bun run validate:imports
bun run preview:schematic
bun run test:draft
```

`preview:schematic` disables PCB generation and renders each native A4 sheet.
`test:draft` checks the generated physical-pin connections, supplier identities,
A4 sheets and absence of PCB output. These checks do not qualify the complete board.
The full `build` and `snapshot` commands remain available for their later validation
stages; do not use a draft render as placement, routing or fabrication evidence.

## Supported component workflow

Use the pinned released converter until the CLI's bundled converter is independently
verified to contain the fix. Updating global tscircuit alone did not establish that.

```sh
node_modules/.bin/easyeda download -i C2847904 -o evidence/rev-0.0.2-alpha.0/C2847904.raweasy.json
node_modules/.bin/easyeda convert -i evidence/rev-0.0.2-alpha.0/C2847904.raweasy.json -o imports/STM32G0B1CBT6/STM32G0B1CBT6.tsx
bun run validate:imports
```

Preserve earlier revision evidence before regeneration. Do not hand-edit generated
symbols, pin mappings, footprints or models to repair imports.

## Next gates

The exact motor model and rear drawing are still needed for mounting holes,
shaft/magnet position, screw clearances and standoffs. No geometry has been guessed.
Continue the complete BOM and USB-PD/power/motor/SWD/IO schematic independently.
Then qualify footprints, models, stock and placement before enabling routing.
Save routes before manual corrections and repeat all required copper checks afterward.

**BOM NOT READY / SCHEMATIC NOT READY / MECHANICS NOT READY / PLACEMENT NOT READY**  
**ROUTING DISABLED / FABRICATION NOT READY**

An eventual fabrication release means ready to order an **untested prototype**.
No order, physical test result or store publication is part of this revision.
