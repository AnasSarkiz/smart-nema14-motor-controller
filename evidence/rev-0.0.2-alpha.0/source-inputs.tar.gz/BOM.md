# Candidate BOM - NOT READY

Revision 0.0.2-alpha.0; identity/import checks 2026-10-02.
Three draft sheets instantiate U1, U4, U6, C1-C7 and R1-R3 (13 parts).
Other rows are candidates or unfinished coverage items, not an assembly BOM.
Basic/Extended below is the class reported by the fetched supplier JSON;
reported LCSC stock is not a reservation or verified current JLC assembly stock.
Ratings, footprint/model registration, assembler inventory and substitutions
remain subject to stage 2 qualification.

| Ref | Function | Manufacturer | MPN | Package | LCSC/JLCPCB Part Number | Basic/Extended | Datasheet | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| U1 | MCU, USB, UCPD, FDCAN | ST | STM32G0B1CBT6 | LQFP48, 7 x 7 mm | C2847904 | Extended | [ST DS13560](https://www.st.com/resource/en/datasheet/stm32g0b1cb.pdf) | Regenerated with easyeda 0.0.360; critical-label audit PASS; MCU draft instantiated |
| U2 | Stepper driver | ADI/Trinamic | TMC2209-LA | QFN28 exposed pad, 5 x 5 mm | C465949 | Unverified | [ADI Rev 1.09](https://www.analog.com/media/en/technical-documentation/data-sheets/TMC2209_datasheet_rev1.09.pdf) | Imported with 3D assets; full footprint/paste/thermal review pending |
| U3 | USB PD protection | ST | TCPP01-M12 | QFN12 exposed pad, 3 x 3 mm | C1121848 | Extended | [ST DS12900](https://www.st.com/resource/en/datasheet/tcpp01-m12.pdf) | Regenerated with easyeda 0.0.360; DB/FLT audit PASS; sink circuit pending; protection does not negotiate PD |
| U4 | Optional magnetic encoder | ams | AS5600-ASOM | SOIC8 | C79815 | Unverified | [Manufacturer-authored datasheet](https://datasheet.lcsc.com/datasheet/pdf/fab02cf30a2c48b5aeeebf03db9fe675.pdf?productCode=C79815) | 3.3 V I2C draft instantiated; optional U4/C6 population; bottom mechanics and models pending |
| U5 | 3.3 V buck candidate | Diodes | AP63203WU-7 | TSOT23-6 | C780769 | Unverified | [Supplier entry](https://www.lcsc.com/pl/product-detail/C780769.html) | Identity checked; manufacturer electrical review/import pending |
| U6 | Classical CAN candidate | TI | SN65HVD230DR | SOIC8 | C12084 | Extended | [TI datasheet](https://www.ti.com/lit/ds/symlink/sn65hvd230.pdf) | Imported with easyeda 0.0.360; draft instantiated, RS=GND; termination/ESD pending; no CAN FD claim |
| C1 | MCU VDD 100 nF | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | X7R, 16 V; imported unchanged; placement pending |
| C3 | MCU VREF+ 100 nF | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | X7R, 16 V; imported unchanged; placement pending |
| C4 | MCU VBAT 100 nF | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | X7R, 16 V; imported unchanged; placement pending |
| C5 | Reset filter 100 nF | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | X7R, 16 V; imported unchanged; placement pending |
| C6 | Encoder supply 100 nF | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | X7R, 16 V; imported unchanged; placement pending |
| C7 | CAN supply 100 nF | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | X7R, 16 V; imported unchanged; placement pending |
| C2 | MCU bulk 4.7 uF nominal | Samsung | CL05A475MP5NRNC | 0402 | C23733 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C23733.pdf) | X5R, 10 V; effective 3.3 V capacitance not qualified |
| R1 | Reset pull-up 10 kOhm | UniRoyal | 0402WGF1002TCE | 0402 | C25744 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C25744.pdf) | 1%; imported unchanged |
| R2 | I2C SCL pull-up 4.7 kOhm | UniRoyal | 0402WGF4701TCE | 0402 | C25900 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C25900.pdf) | 1%; bus capacitance/rise-time qualification pending |
| R3 | I2C SDA pull-up 4.7 kOhm | UniRoyal | 0402WGF4701TCE | 0402 | C25900 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C25900.pdf) | 1%; bus capacitance/rise-time qualification pending |
| J_SWD | Official Standard JST SWD + Reset Side | JST | SM05B-SRSS-TB(LF)(SN) | JST SH 5-pin, 1 mm, side entry | C136657 | Unverified | [JST SH series](https://www.jst-mfg.com/product/pdf/eng/eSH.pdf) | Official package 0.8.0 installed; VOUT/VTREF distinction unresolved |
| J_USB | USB-C PD + USB2 receptacle | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Exact power rating, mount and shaft/edge clearance required |
| Q_PD / power protection | Sink MOSFET, inrush/current and reverse protection | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Complete startup and regenerative-energy design first |
| D_USB | USB data ESD | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Compatible with USB data and high-voltage PD architecture |
| D_VM / brake parts | Motor transient/regen protection | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Voltage margin and energy qualification required |
| L1 | Buck inductor | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Regulator ripple, saturation current and thermal design |
| C_VM | Motor bulk capacitance | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Voltage, ESR, ripple current, inrush and regen requirements |
| C* | VM/logic/charge-pump/encoder/USB/buck decoupling | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Every capacitor needs exact value, rating and supplier import |
| R_SA / R_SB | Current sense | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Clarify RMS/peak current; verify rating and footprint |
| R* | Bias, pull-ups, dividers, SWD/UART/IO support | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Exact per-reference list requires completed schematic |
| R_CAN / termination control | Selectable CAN termination | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | 120 ohm resistor plus verified selectable connection |
| TEMP | Temperature sensor or NTC network | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Thermal trip, fault behavior and sensing placement |
| LED* | Power, status, fault indicators | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Exact LED and current-limiting resistor imports |
| J_IO | Consolidated CAN/STEP/DIR/limits/low-voltage IO | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Final pin count, current and access clearance |
| J_MOTOR | Four-wire motor connection | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Current rating for intended phase-current convention |

The grouped pending rows are a coverage checklist, not an assembly BOM.
Do not export or order them. A complete per-reference BOM must be reviewed
before placement and routing; supplier substitutes require new imports and
validation.

## Supplier import evidence

Raw records and converter outputs are preserved in evidence/rev-0.0.2-alpha.0.
Reported LCSC stock from those records: C1525 869375, C23733 100, C25744 235900, C25900 420100, C12084 17337.
These values may be cached; recheck assembly inventory before freezing the BOM.
C52923 / Samsung CL05A105KA5NQNC, 1 uF, 0402, Basic, was also imported as a
support-component candidate but is not instantiated and has no production reference.

The full TMC2209/PD/buck/IO networks still require a complete per-reference BOM.
No grouped pending row can be used as a fabrication BOM.
