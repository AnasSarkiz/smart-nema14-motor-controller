# Issues and remaining work

Revision 0.0.4-alpha.0, 2026-10-02.

## B001 - STM32 critical label loss: RESOLVED tooling issue

Part C2847904 / STM32G0B1CBT6, stage 2. Older bundled importer output lost
labels on physical pins 6, 7, 33 and 34. Global tscircuit was updated to
0.0.2729, then the component was regenerated with released `easyeda@0.0.360`.
Current aliases are VDD/VDDA, VSS/VSSA, PA11_PA9_ and PA12_PA10_.
The unchanged critical-label audit passes. Old outputs are preserved.
No manual component edits, pin overrides or generic replacements were used.
This is no longer a component blocker; full application qualification remains stage 2 work.

## B002 - TCPP control/fault label loss: RESOLVED tooling issue

Part C1121848 / TCPP01-M12, stage 2. Regeneration with released
`easyeda@0.0.360` restores physical pin 10 DB and pin 11 FLT.
The unchanged audit passes. No component definition was manually patched.
The complete sink protection circuit remains to be designed and reviewed.

## B003 - Exact motor rear mechanics: BLOCKING user-supplied requirement

Stages 1 and 3. Exact motor model and rear mechanical drawing remain absent:
rear mounting holes, screw/head clearances, rear shaft, magnet holder,
standoffs and tolerance stack. The reference motor is not a selected target.
Do not infer rear mounting geometry from front NEMA dimensions.
Mounting holes, shaft cutout, encoder center, component placement and routing
remain gated. Independent schematic/BOM development can continue.

## B004 - Complete schematic and BOM: IN PROGRESS

Stages 2 and 3. Five A4 draft sheets with 38 imported parts implement MCU,
encoder, CAN, logic buck and TMC2209 support. USB-C/PD protected power input,
programmer power, temperature, LEDs, termination and external connectors
remain unfinished. A partial schematic is not a functioning controller.
Verify each supplier import, pin/function, rating, footprint, model and assembler
inventory before accepting the complete BOM. C2 effective capacitance at 3.3 V
must be qualified; nominal 4.7 uF alone does not establish this.

## B005 - Official programmer power integration: PENDING DESIGN

Stage 2. `StandardJstSwdResetSide` pin 1 is VOUT from the programmer's voltage
selector, not an established passive VTREF input. Complete 3.3 V operation,
power isolation/backfeed handling and documented series resistors before wiring.
The required official package is retained; no custom connector is substituted.

## B006 - Motor current, thermal and regeneration envelope: PENDING DESIGN

Stages 1 and 2. Resolve RMS/peak convention against the exact motor,
load/speed/inertia, PD current budget, fallback and braking energy.
1.2 A/phase is an intended upper target, not a measured rating.
The 180 mOhm / 1 W sense draft has nominal 1.149 A RMS full scale and a
proposed 1.0 A firmware cap; it cannot qualify the 1.2 A upper target.
Preliminary buck/sense/bulk-energy calculations are in references/POWER-AND-MOTOR-REVIEW.md.
Motor bulk stores only 12.9 mJ extra between 20 V and 23 V nominal: it cannot
replace a regenerative-energy solution. Complete power-path/fault calculations
against the exact motor/load, then physical tests.

## B007 - Stackup and copper geometry: PENDING LATER STAGES

Stages 1, 3, 4 and 6. Choose the manufacturer's four-layer stackup, thickness,
copper weight and impedance construction. Current previews contain no PCB
geometry, so they cannot qualify trace width, drills, vias or power bottlenecks.

## B008 - Datasheet/package visual review: PENDING REVIEW

Earlier local ST PDF downloads failed; those diagnostics remain in revision
0.0.1 evidence. Current manufacturer PDF text was accessed through the web;
a working AS5600 PDF URL is now recorded in references/SOURCES.md.
Full rendered land-pattern and 3D registration review remains pending.
No missing component label is attributed to these download failures.

## Draft warnings reviewed

AS5600 and TMC2209 lack a `requires_power` classification. These two
metadata warnings remain visible. The official MCU importer now supplies
manufacturer pin attributes, including VSS ground classification; its prior
warning is resolved without manual edits. Independent generated-net checks
confirm U1 pin 7 to GND, U4 pins 1/2 to 3.3 V and U2 pins 15 to V3V3,
22/28 to VM and 3/18/29 to GND. Accept the remaining metadata warnings only
for this schematic draft; full application/footprint/fabrication qualification
remains open.

## Remaining fabrication stages

No PCB placement, routed shorts/DRC, routed snapshots, Gerbers/drills/assembly
BOM/CPL, assembler feedback or physical tests have been completed.
There are no routes to save or manually repair yet.

## B009 - Candidate import audit: C5127775 RESOLVED; library failures excluded

Stage 2. Official `tsci upgrade` completed, global tscircuit 0.0.2732 resolves
CLI 0.1.2230; board dependencies pin that CLI and EasyEDA 0.0.366.
Converter #587/#588 and CLI #5111 merge status was independently verified.
C5127775 regenerates as a native 0.18 Ω resistor with original pins/pads 1/2.
The preserved legacy generic file is excluded, not patched.
R5/R6 now use this genuine 180 mOhm/1 W/1% import.

C2046441, C5127782 and C723743 remain supplier-library unavailable.
Verified replacements imported through the official CLI:

- C19947652 / Bourns SRN6028C-3R9M: 3.9 uH; L1 now uses its own exact
  footprint. Manufacturer dimensions and preliminary ripple calculation reviewed.
- C5127775 / Milliohm HoLRT1206-1W-180mR-1%: replaces unavailable C5127782.
- C5127776 / Milliohm HoLRT1206-1W-150mR-1%: native 0.15 Ω electrical
  candidate for C723743; not instantiated. AEC-Q200 qualification is unestablished.

Audit passes raw resistance, exact supplier identities and all 67 physical
pin-to-pad mappings across these three parts plus regenerated MCU/TCPP01.
An isolated unrouted footprint fixture has zero placement errors/warnings.
This is not full 35 x 35 mm board placement. Current assembler stock, worst-case
current, resistor pulse/temperature ratings and complete-board qualification
remain pending. See evidence/rev-0.0.4-alpha.0/IMPORT-PIN-PAD-AUDIT.json and
IMPORT-PROVENANCE.json. No generated component was manually edited.

## B010 - Protected USB power path: IN PROGRESS

TCPP CTRLVBUS pin 6 was incorrectly reserved for a GPIO in the candidate plan;
it is now correctly identified as an analog OVP divider input. No incorrect
connection was wired. VBUS_INRUSH_OUT and VM are unsupplied draft interfaces.
Resolve default-5 V bootstrap, <=10 uF connector-side capacitance, controlled
bulk charging, reverse-current protection, OVP tolerances and regeneration
before connecting these supplies or enabling PCB routing. Imported TI C3662793
eFuse is an unused candidate; application/footprint qualification is pending.
