# Validation - Smart NEMA 14 Motor Controller

Date: **2026-10-02**. Board revision: **0.0.4-alpha.0**.
Status: **SCHEMATIC IN PROGRESS; MECHANICS BLOCKED; NOT FABRICATION READY; ROUTING DISABLED**.

New isolated design, no source-board predecessor. Local Git has no source commit
or remote. Reviewed source/dependency hashes and artifacts identify this revision
in `evidence/rev-0.0.4-alpha.0/MANIFEST.json` and `source-inputs.tar.gz`.
Revisions 0.0.1, 0.0.2 and 0.0.3 evidence remain preserved. The 0.0.1 label-loss
findings are superseded by the released-converter audit below. Earlier envelope
outputs are historical; the 0.0.3 draft is preserved in this revision’s previous-draft/.

## Stage record

| Stage | Status | Evidence / outstanding work |
| --- | --- | --- |
| 1. Confirm requirements | blocked | Exact motor rear drawing/shaft/mounting geometry absent (B003); operating/thermal envelope and ordered stackup still to be qualified |
| 2. Schematic and BOM | in progress | MCU/TCPP critical-label audit passes; five draft A4 sheets, 38 imported parts and 86 physical-pin checks; regulator and motor support added, full protected power/PD/SWD/IO circuit and BOM unfinished |
| 3. Unrouted placement | blocked | Exact motor and complete schematic/BOM qualification required; no PCB coordinates or mounting holes assigned |
| 4. Routed copper | not started | Routing explicitly disabled; no copper geometry exists |
| 5. Automated and visual routed checks | not started | Preliminary schematic checks passed below; no routed board/DRC/snapshot qualification |
| 6. Approve prototype fabrication | not started | No Gerber, drill, assembly BOM/CPL or assembler feedback package |
| 7. Physical prototype tests | not started | No prototype or actual physical evidence; no verified operating limit |
| 8. Store release | not started | No release or publication; incomplete prototype design |

None of the eight complete-board stages has passed. Independent schematic/BOM
work continues while exact motor mechanics gates placement and routing.

## Requirements and unresolved limits

The supplied brief requires a motor-mounted standalone controller, STM32G0B1,
TMC2209, real USB-C PD negotiation, USB data where practical, bottom-side
AS5600, CAN, STEP/DIR, two limit inputs, temperature sensing, power/status/fault
LEDs and the official Standard JST programming connector. Target is 35 x 35 mm
and four layers, with accessible edge connectors and exact rear shaft alignment.

- Supply: default 5 V startup; requested 9/12/15/20 V PD where offered. Prefer
  12/15 V operation. Motor disabled until a valid contract, measured voltage,
  current budget and driver setup are confirmed. Detailed inrush/fallback/
  regen behavior remains unresolved.
- Intended phase current: 0.3-1.0 A typical, approximately 1.2 A continuous
  upper design target. RMS/peak convention and physically verified thermal
  limits are unresolved. These are not tested ratings.
- Interface voltage, external-input source impedance and cable protection
  remain to be specified. CAN candidate is classical CAN at 3.3 V logic.
- Mounting: exact motor, rear drawing, screw diameters/heads, shaft clearance,
  standoffs, magnet holder and encoder air gap are unresolved. No holes placed.
- Manufacturer: JLCPCB four-layer rigid FR4, through vias. Proposed L1 component/
  signal/power, L2 GND, L3 power/slow signals, L4 encoder/signals arrangement.
  No plane has been created and no stackup/thickness has been selected.

### Proposed manufacturing rules - not copper validation

Conservative candidate values below must be reconciled with the selected
stackup, imported lands, thermal-via construction and JLCPCB DFM before routing.
The [JLCPCB rigid capability page](https://jlcpcb.com/capabilities/pcb-capabilities/)
was consulted on 2026-10-02; quoted capability minima are not power-current
ratings. Use manufacturer-specific geometry/current analysis for critical nets.

| Feature | Proposed design target | Status |
| --- | --- | --- |
| Signal trace width | At least 0.15 mm except a documented USB impedance design | Not implemented/measured |
| Copper clearance | At least 0.15 mm, with larger spacing where protection needs it | Not implemented/measured |
| Ordinary through via | 0.30 mm drill / 0.60 mm copper diameter | Not implemented/measured |
| Ordinary drill edge-to-copper | At least 0.25 mm, including same-net pads | Not implemented/measured |
| Copper-to-board edge | At least 0.30 mm | Not implemented/measured |
| Thermal via array | Pending; review exposed-pad paste and filling/tenting requirements separately | No exception approved |
| Power trace widths | Pending load, copper weight and thermal calculation; inspect narrow necks | No current-capacity claim |
| USB differential impedance | 90 ohm target on chosen manufacturer stackup | Stackup/routing unselected |

The earlier 0.0.1 empty-envelope build defaulted to 1.4 mm thickness and the library's own
DRC minima (including 0.10 mm traces and 0.20/0.30 mm via dimensions). Those
defaults **are not approved fabrication settings**. Do not generate fabrication
outputs from that envelope or treat them as the rules above.

## Tool/dependency record

| Tool | Version |
| --- | --- |
| Bun | 1.3.9 |
| Global tscircuit before update | 0.0.2696 |
| Global tscircuit after first requested update | 0.0.2729 |
| Current global tscircuit after tsci upgrade | 0.0.2732 |
| CLI resolved from global wrapper | 0.1.2230 |
| Local tscircuit | 0.0.2732 |
| Local @tscircuit/cli | 0.1.2230 |
| Released EasyEDA converter / CLI bundled requirement | 0.0.366 |
| TypeScript / Biome | 5.9.3 / 2.5.15 |
| Standard JST Programmer | 0.8.0 |
| Direct sheet rendering dependencies | circuit-to-svg 0.0.437 / sharp 0.32.6 |

Dependencies are exactly pinned in package.json and bun.lock. The installed
core/props/transitive versions are recorded in the manifest. The requested `tsci upgrade` ran successfully before imports. The global
wrapper reports tscircuit 0.0.2732; its resolved CLI package is 0.1.2230 (a stale
unrelated globally hoisted CLI was not mistaken for the wrapper's runtime).
Local CLI 0.1.2230 bundles the easyeda ^0.0.366 requirement. CLI-generated
resistance and pin/pad audit verify the actual behavior, not just version strings.
Install retains a circuit-json peer warning; no relevant type/build/check failure
remains. Exact package versions are in this revision's VERSIONS.json.

## Released-converter component audit

The upstream converter #587/#588 and CLI #5111 are confirmed merged; metadata
is in UPSTREAM-RELEASE.json. C2847904, C1121848, C5127775, C5127776 and C19947652
were regenerated through `tsci import --jlcpcb --use-exact-footprint` using CLI
0.1.2230. Raw supplier inputs were separately saved with released EasyEDA
0.0.366. Current output hashes, raw hashes and reproduction evidence are in
this revision's IMPORT-PROVENANCE.json. Neither definitions nor footprints,
symbols, pin aliases, pad mappings or imported attributes were manually patched.
Generated MCU/TCPP output was copied byte-for-byte to the existing canonical paths.

Four CLI outputs are byte-identical to direct converter reproduction. MCU CLI
output additionally includes official fetched datasheet attributes and uses the
CLI serializer; a second official MCU import reproduces its exact bytes. The
native raw-to-port/pad audit confirms all five identities and all 67 mappings,
including the MCU's 48 and TCPP's 13 pads. The unchanged critical audit below
continues to pass. Full model/paste/application qualification remains pending.

| Part / physical pin | Current generated aliases | Datasheet comparison |
| --- | --- | --- |
| C2847904 pin 6 | VDD, VDDA | PASS, ST DS13560 Rev 6 Table 12 |
| C2847904 pin 7 | VSS, VSSA | PASS |
| C2847904 pin 33 | PA11_PA9_ | PASS, default PA11 / optional PA9 remap |
| C2847904 pin 34 | PA12_PA10_ | PASS, default PA12 / optional PA10 remap |
| C1121848 pin 10 | DB | PASS, ST DS12900 Rev 7 Table 1 |
| C1121848 pin 11 | FLT | PASS |

The existing critical-import audit is unchanged from 0.0.1 and now passes.
Generated MCU pads 1-48 and TCPP pads 1-13 (including EP) are present exactly
once. This confirms labels/pad presence, not full land-pattern/paste/model or
application qualification. B001/B002 are closed as tooling issues.

## Current schematic/BOM progress

- Five native A4 sheets: MCU, Encoder, CAN, Logic Power, Motor Driver, each
  297 x 210 mm. All 38 instantiated electronic parts are genuine supplier
  imports: U1/U2/U4/U5/U6, C1-C21, R1-R11 and L1.
- Existing MCU supplies, NRST, I2C1, FDCAN2, optional AS5600 in 3.3 V mode
  and SN65HVD230 connections remain. AS5600 OUT/PGO are unused and OTP
  programming is excluded. Magnet mechanics are unresolved.
- AP63203 fixed 3.3 V regulator uses 10 uF input, 100 nF bypass/bootstrap,
  3.9 uH Bourns inductor and two nominal 22 uF output capacitors. Its input net
  VBUS_INRUSH_OUT awaits the protected USB power path. The preliminary 0.3 A
  logic budget is not a tested rating; bias, inductance tolerances, switching
  behavior, fault saturation and thermal/layout qualification remain open.
- TMC2209 support now includes charge-pump/regulator capacitors, nominal
  200 uF/35 V polarized VM bulk, two 180 mOhm/1 W sense resistors, hardware
  disable pull-up, STEP/DIR pull-downs and MCU UART/STEP/DIR/DIAG/ENN wiring.
  VREF derives from the driver's own 5VOUT using a 10k/10k divider and filter.
  VM remains a separate, unsupplied net pending the protected power path.
- Nominal full-scale current calculation is 1.149 A RMS for the selected
  180 mOhm resistors. A 1.0 A firmware cap and 0.3 A bring-up setting are
  proposed, not implemented or verified. The approximately 1.2 A target is
  not met or qualified by this draft. See POWER-AND-MOTOR-REVIEW.md for
  calculations, tolerances and regeneration limitations.
- C2046441, C5127782 and C723743 cannot be downloaded through the converter.
  The prior C5127775 converter bug is resolved: raw 180mΩ now generates a
  native 0.18 Ω resistor with both pads intact. C19947652 and C5127775 replace
  the unavailable inductor/180 mOhm candidate using their own official footprints.
  C5127776 imports as 0.15 Ω with two pads; it is an unused electrical candidate,
  with AEC-Q200 qualification unestablished. Original missing-library parts
  remain blocked/excluded. C167251 remains correctly rejected as an LDO.
  No failed component was recreated or patched.
- C3662793 TPS259470L is an imported, unused power-path candidate; its
  protection/variant/polygon geometry and application are not qualified.
- Corrected the MCU pin plan: TCPP01 pin 6 CTRL_VBUS is an analog OVP divider
  input, not a GPIO control. No imported component definition was changed.
- USB connector/PD protection/inrush/reverse blocking, regeneration handling,
  official programming connector, external IO, termination/protection,
  temperature and LEDs remain stage 2 work. MLCC bias and imported lands/paste
  remain unqualified. No PCB coordinates, holes, planes, traces or vias exist.

## Commands and results for the implemented draft

All commands run from the board directory. Exact argument arrays, exit codes
and log paths are in evidence/rev-0.0.4-alpha.0/CHECK-RESULTS.json.

| Command | Observed result / scope |
| --- | --- |
| tsci upgrade | Exit 0; global tscircuit 0.0.2732, resolved CLI 0.1.2230; current upgrade.log / VERSIONS.json |
| tsci import for C2847904, C1121848, C5127775, C5127776, C19947652 | Exit 0; official exact footprints; raw/current output and reproduction evidence in current provenance |
| bun run preview:imports / test:imports | Exit 0; isolated unrouted fixture, native 0.18/0.15 Ω, 3.9 uH, 67 pin/pad mappings and zero generated error elements |
| tsci check placement scripts/import-audit.circuit.tsx | Exit 0; zero placement errors/warnings for separated import fixture; NOT full board placement |
| bun run validate:imports | Exit 0; six critical label checks pass without audit changes |
| bun run format:check | Exit 0; authored source/config/scripts only; generated imports untouched |
| bun run typecheck | Exit 0 for source and generated imports |
| tsci check netlist index.circuit.tsx | Exit 0; implemented netlist reviewed; unfinished pins remain visible |
| tsci check pin_specification index.circuit.tsx | Exit 0; no errors, two metadata warnings retained and reviewed below |
| tsci check source index.circuit.tsx | Exit 0; zero errors and warnings |
| tsci check schematic-placement index.circuit.tsx | Exit 0; no remaining placement issues reported; explicit visual review also completed |
| bun run preview:schematic | Exit 0; routing disabled and PCB output disabled; all five sheets rendered |
| bun run test:draft | Exit 0; 86 physical-pin net checks, 38 supplier parts, five A4 sheets, five distinct power/ground nets and zero PCB elements |

These are preliminary checks on implemented blocks. They do not establish a
complete netlist, validated BOM, PCB placement or absence of routed shorts.
Actionable schematic box-width, decoupling-spacing and supply-orientation
findings were corrected using layout props, preserving electrical connections.
No DRC or validation option was suppressed.

### Reviewed warnings

Two converter metadata warnings remain: U4 and U2 lack `requires_power`
classifications. Manufacturer pin functions and independent physical-pin checks
confirm U4 pins 1/2 on V3V3 and U2 VCC_IO/VS1/VS2 on their intended rails.
Accept these metadata warnings for this partial schematic only; retain the logs
and re-review during complete-board qualification. The official MCU importer
adds datasheet attributes and resolves its earlier ground-classification warning.
No imported metadata was manually changed. Peer-version install warnings confer
no electrical/fabrication qualification.

## Visual and generated-artifact inspection

Inspected the actual current PNG for each native sheet:

- dist/index/schematic-MCU.png and .svg: readable supply/reset network,
  imported MCU labels, unfinished pins and explicit draft notes within A4.
- dist/index/schematic-Encoder.png and .svg: tied 3.3 V supply pins,
  DIR/GND, two pull-ups, decoupling, OUT/PGO no-connects and mechanical note.
- dist/index/schematic-CAN.png and .svg: transceiver, RS/GND, supply capacitor,
  MCU signal labels and explicit missing connector/termination/ESD note.
- dist/index/schematic-LogicPower.png and .svg: fixed-output regulator,
  bootstrap/inductor and capacitor polarities/nets, unsupplied input and draft
  protection/current-budget notes.
- dist/index/schematic-MotorDriver.png and .svg: all driver signal/power labels,
  charge pump, VM capacitors, polarity, UART, sense resistors, VREF and startup
  pull resistors. Supported instance display arrangement/width changes resolve
  label and grouping issues without changing imported pin definitions.

The CLI's generic schematic.png/.svg show only the first sheet; the additional
native per-sheet renderer ensures the other sheets are actually inspected.
Current circuit.json has 38 source/schematic components, five A4 sheets,
zero PCB elements and no error elements. Two metadata warnings remain as above.
Earlier empty PCB images remain in rev-0.0.2's previous-envelope/.
The preceding five-sheet draft is preserved in current previous-draft/.
Downloaded 3D models, full package lands/paste and mechanical assemblies have
not been visually qualified. Local AP63203 datasheet pages 2, 9 and 13 were rendered and inspected;
manufacturer TMC2209/TCPP documents were reviewed through their online PDFs.
Full supplier package/PDF/land-pattern qualification remains incomplete.
See references/SOURCES.md and POWER-AND-MOTOR-REVIEW.md for exact source links.

CLI schematic-placement can report issues with exit 0, so the final empty issue
report and actual renders were inspected separately from the return code.
Motor-driver box width, bootstrap-capacitor orientation, VM capacitor grouping
and UART resistor label orientation were corrected through schematic layout props.
No routing or error-check option was suppressed.

### Replacement footprint fixture review

Actual dist/scripts/import-audit/pcb.png and pcb.svg were inspected. This is a
separate 80 x 35 mm four-layer, unrouted fixture, not a proposed controller PCB.
Its two resistor footprints each preserve the supplier's 1.207516 x 1.7010126 mm
lands, centers +/-1.478788 mm. Bourns lands are 1.999996 x 6.499987 mm,
centers +/-2.250059 mm, matching the manufacturer's recommended 6.5 mm square
layout/2.5 mm inner gap within source rounding. MCU/TCPP pad counts and physical
port links were inspected/audited; exact supplier outlines/courtyards are retained.
No copper traces or vias exist in this fixture. Placement reports zero errors
and warnings at its deliberately separated coordinates. It does not establish
connector access, mounting fit, 35 mm density or manufacturing qualification.

The first diagnostic fixture build had missing test-net connections and sandbox
supplier-fetch failures; its log is preserved. The completed fixture connects
its tested power/passive pins and runs required supplier checks with network
access. No supplier check or DRC was disabled. Current source/config/typecheck
and full draft evidence reflect the corrected fixture source.

## Required later checks

After stage 2 and motor mechanics are complete, run the complete pre-route
checks (including repeating the preliminary ones on the full source):

```sh
tsci check netlist index.circuit.tsx
tsci check pin_specification index.circuit.tsx
tsci check source index.circuit.tsx
tsci check schematic-placement index.circuit.tsx
tsci check placement index.circuit.tsx
```

Only then enable routing, save generated routes and correct any actual defects
through supported native route/cache APIs. Measure widths, clearances, power
necks, holes/vias and keepouts on generated geometry, and run:

```sh
tsci build index.circuit.tsx --pcb-png --pcb-svgs --schematic-svgs
tsci check shorts dist/index/circuit.json
tsci snapshot index.circuit.tsx
```

Review every copper layer, critical detail and changed snapshot before prototype
Gerber/drill/BOM/CPL export and assembler review from the identical revision.
An empty or PCB-disabled preview cannot pass those checks on behalf of a board.

## Readiness

**BOM: NOT READY**  
**SCHEMATIC: NOT READY (partial draft reviewed)**  
**MECHANICS: NOT READY (exact motor rear geometry required)**  
**PLACEMENT: NOT READY**  
**ROUTING: DISABLED**  
**FABRICATION: NOT READY**

The remaining external requirement blocker is B003. Other circuit, supplier,
thermal, stackup and fabrication work remains explicitly unfinished in issues.md.
No physical hardware test, fabrication order or publication has occurred.
