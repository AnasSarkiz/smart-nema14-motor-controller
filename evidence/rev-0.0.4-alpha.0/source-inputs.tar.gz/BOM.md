# Candidate BOM - NOT READY

Revision 0.0.4-alpha.0; identity/import checks 2026-10-02.
Five draft sheets instantiate U1/U2/U4/U5/U6, C1-C21, R1-R11 and L1 (38 parts).
Other rows are candidates or unfinished coverage items, not an assembly BOM.
Basic/Extended below is the class reported by the fetched supplier JSON;
reported LCSC stock is not a reservation or verified current JLC assembly stock.
Ratings, footprint/model registration, assembler inventory and substitutions
remain subject to stage 2 qualification.

| Ref | Function | Manufacturer | MPN | Package | LCSC/JLCPCB Part Number | Basic/Extended | Datasheet | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| U1 | MCU, USB, UCPD, FDCAN | ST | STM32G0B1CBT6 | LQFP48, 7 x 7 mm | C2847904 | Extended | [ST DS13560](https://www.st.com/resource/en/datasheet/stm32g0b1cb.pdf) | Regenerated with official CLI 0.1.2230 / easyeda 0.0.366; critical-label audit PASS; MCU draft instantiated |
| U2 | Stepper driver | ADI/Trinamic | TMC2209-LA | QFN28 exposed pad, 5 x 5 mm | C465949 | Unverified | [ADI Rev 1.09](https://www.analog.com/media/en/technical-documentation/data-sheets/TMC2209_datasheet_rev1.09.pdf) | Draft instantiated with support/sense network; 5 V fallback motor disabled; full footprint/paste/thermal review pending |
| U3 | USB PD protection | ST | TCPP01-M12 | QFN12 exposed pad, 3 x 3 mm | C1121848 | Extended | [ST DS12900](https://www.st.com/resource/en/datasheet/tcpp01-m12.pdf) | Regenerated with official CLI 0.1.2230 / easyeda 0.0.366; DB/FLT audit PASS; sink circuit pending; protection does not negotiate PD |
| U4 | Optional magnetic encoder | ams | AS5600-ASOM | SOIC8 | C79815 | Unverified | [Manufacturer-authored datasheet](https://datasheet.lcsc.com/datasheet/pdf/fab02cf30a2c48b5aeeebf03db9fe675.pdf?productCode=C79815) | 3.3 V I2C draft instantiated; optional U4/C6 population; bottom mechanics and models pending |
| U5 | 3.3 V logic buck | Diodes | AP63203WU-7 | TSOT26 | C780769 | Extended | [Diodes DS41326 Rev 3-2](https://www.diodes.com/datasheet/download/AP63200-AP63201-AP63203-AP63205.pdf) | Imported unchanged; draft instantiated; input power path, effective capacitance and thermal qualification pending |
| U6 | Classical CAN candidate | TI | SN65HVD230DR | SOIC8 | C12084 | Extended | [TI datasheet](https://www.ti.com/lit/ds/symlink/sn65hvd230.pdf) | Imported with easyeda 0.0.360; draft instantiated, RS=GND; termination/ESD pending; no CAN FD claim |
| C1 | MCU VDD 100 nF | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | X7R, 16 V; imported unchanged; placement pending |
| C3 | MCU VREF+ 100 nF | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | X7R, 16 V; imported unchanged; placement pending |
| C4 | MCU VBAT 100 nF | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | X7R, 16 V; imported unchanged; placement pending |
| C5 | Reset filter 100 nF | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | X7R, 16 V; imported unchanged; placement pending |
| C6 | Encoder supply 100 nF | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | X7R, 16 V; imported unchanged; placement pending |
| C7 | CAN supply 100 nF | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | X7R, 16 V; imported unchanged; placement pending |
| C2 | MCU bulk 4.7 uF nominal | Samsung | CL05A475MP5NRNC | 0402 | C23733 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C23733.pdf) | X5R, 10 V; effective 3.3 V capacitance not qualified |
| R1 | Reset pull-up 10 kOhm | UniRoyal | 0402WGF1002TCE | 0402 | C25744 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C25744.pdf) | 1%; imported unchanged |
| R2 | I2C SCL pull-up 4.7 kOhm | UniRoyal | 0402WGF4701TCE | 0402 | C25900 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C25900.pdf) | 1%; bus capacitance/rise-time qualification pending |
| R3 | I2C SDA pull-up 4.7 kOhm | UniRoyal | 0402WGF4701TCE | 0402 | C25900 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C25900.pdf) | 1%; bus capacitance/rise-time qualification pending |
| C8 | Buck input 10 uF/50 V | Samsung | CL31A106KBHNNNE | 1206 | C13585 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C13585.pdf) | Effective input capacitance/ripple and controlled charging pending |
| C9 | Buck input HF 100 nF/50 V | Yageo | CC0603KRX7R9BB104 | 0603 | C14663 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C14663.pdf) | Close VIN/GND loop required |
| C10 | Buck bootstrap 100 nF/50 V | Yageo | CC0603KRX7R9BB104 | 0603 | C14663 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C14663.pdf) | BST to SW, not to ground |
| C11 | Buck output 22 uF/25 V | Samsung | CL21A226MAQNNNE | 0805 | C45783 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C45783.pdf) | Effective capacitance/loop stability pending |
| C12 | Buck output 22 uF/25 V | Samsung | CL21A226MAQNNNE | 0805 | C45783 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C45783.pdf) | Parallel C11; effective capacitance pending |
| C13 | TMC flying charge pump 22 nF/50 V | Samsung | CL05B223KB5VPNC | 0402 | C307335 | Extended | [Supplier datasheet](https://www.lcsc.com/datasheet/C307335.pdf) | Between CPO and CPI |
| C14 | TMC pump reservoir 100 nF/50 V | Yageo | CC0603KRX7R9BB104 | 0603 | C14663 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C14663.pdf) | VCP to VM, not ground |
| C15 | TMC 5VOUT regulator 4.7 uF/50 V | Samsung | CL21A475KBQNNNE | 0805 | C98192 | Extended | [Supplier datasheet](https://www.lcsc.com/datasheet/C98192.pdf) | Effective capacitance at 5 V must remain adequate |
| C16 | TMC VIO 100 nF/16 V | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | 3.3 V logic |
| C17 | TMC VM HF 100 nF/50 V | Yageo | CC0603KRX7R9BB104 | 0603 | C14663 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C14663.pdf) | Near VS pins and EP |
| C18 | TMC VM ceramic 10 uF/50 V | Samsung | CL31A106KBHNNNE | 1206 | C13585 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C13585.pdf) | Effective capacitance at motor voltage pending |
| C19 | TMC VM bulk 100 uF/35 V | Panasonic | EEEFPV101XAP | SMD 6.3 x 7.7 mm | C178585 | Extended | [Supplier datasheet](https://www.lcsc.com/datasheet/C178585.pdf) | Polarized, pin1 positive; 600 mA/160 mOhm at 100 kHz; ripple/layout pending |
| C20 | TMC VM bulk 100 uF/35 V | Panasonic | EEEFPV101XAP | SMD 6.3 x 7.7 mm | C178585 | Extended | [Supplier datasheet](https://www.lcsc.com/datasheet/C178585.pdf) | Parallel C19; nominal 200 uF total, -20% minimum 160 uF; not a brake |
| C21 | TMC VREF filter 100 nF/16 V | Samsung | CL05B104KO5NNNC | 0402 | C1525 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C1525.pdf) | VREF to GND |
| R4 | TMC UART TX isolation 1 kOhm | UniRoyal | 0402WGF1001TCE | 0402 | C11702 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C11702.pdf) | TX through resistor, MCU RX directly on single-wire UART |
| R5 | TMC phase A sense 180 mOhm/1 W | Milliohm | HoLRT1206-1W-180mR-1% | 1206 | C5127775 | Extended | [Supplier record](https://www.lcsc.com/product-detail/C5127775.html) | 1%; fixed official native import, 0.18 Ω and both pads audited; nominal 1.149 A RMS full scale; proposed firmware cap 1 A; pulse/temperature/Kelvin review pending |
| R6 | TMC phase B sense 180 mOhm/1 W | Milliohm | HoLRT1206-1W-180mR-1% | 1206 | C5127775 | Extended | [Supplier record](https://www.lcsc.com/product-detail/C5127775.html) | Match R5; official footprint, no manual edits |
| R7 | TMC ENN pull-up 10 kOhm | UniRoyal | 0402WGF1002TCE | 0402 | C25744 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C25744.pdf) | Hardware disabled while MCU resets |
| R8 | TMC STEP pull-down 10 kOhm | UniRoyal | 0402WGF1002TCE | 0402 | C25744 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C25744.pdf) | Defined reset state |
| R9 | TMC DIR pull-down 10 kOhm | UniRoyal | 0402WGF1002TCE | 0402 | C25744 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C25744.pdf) | Defined reset state |
| R10 | TMC VREF upper 10 kOhm | UniRoyal | 0402WGF1002TCE | 0402 | C25744 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C25744.pdf) | From 5VOUT; review divider/regulator tolerances |
| R11 | TMC VREF lower 10 kOhm | UniRoyal | 0402WGF1002TCE | 0402 | C25744 | Basic | [Supplier datasheet](https://www.lcsc.com/datasheet/C25744.pdf) | To GND; nominal VREF 2.5 V |
| L1 | Buck 3.9 uH power inductor | Bourns | SRN6028C-3R9M | 6 x 6 mm, max 2.8 mm height | C19947652 | Extended | [Bourns datasheet](https://bourns.com/docs/Product-Datasheets/SRN6028C.pdf) | +/-20%; DCR 28 mOhm +/-20%; 3.3 A Irms / 3.9 A Isat typical at 25 C; own 6.5 mm lands reviewed; screening calculation updated |
| J_SWD | Official Standard JST SWD + Reset Side | JST | SM05B-SRSS-TB(LF)(SN) | JST SH 5-pin, 1 mm, side entry | C136657 | Unverified | [JST SH series](https://www.jst-mfg.com/product/pdf/eng/eSH.pdf) | Official package 0.8.0 installed; VOUT/VTREF distinction unresolved |
| J_USB | USB-C PD + USB2 receptacle | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Exact power rating, mount and shaft/edge clearance required |
| Q_PD / power protection | Sink MOSFET, inrush/current and reverse protection | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Complete startup and regenerative-energy design first |
| D_USB | USB data ESD | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Compatible with USB data and high-voltage PD architecture |
| D_VM / brake parts | Motor transient/regen protection | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Voltage margin and energy qualification required |
| C* | VM/logic/charge-pump/encoder/USB/buck decoupling | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Every capacitor needs exact value, rating and supplier import |
| R* | Bias, pull-ups, dividers, SWD/UART/IO support | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Exact per-reference list requires completed schematic |
| R_CAN / termination control | Selectable CAN termination | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | 120 ohm resistor plus verified selectable connection |
| TEMP | Temperature sensor or NTC network | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Thermal trip, fault behavior and sensing placement |
| LED* | Power, status, fault indicators | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Exact LED and current-limiting resistor imports |
| J_IO | Consolidated CAN/STEP/DIR/limits/low-voltage IO | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Final pin count, current and access clearance |
| J_MOTOR | Four-wire motor connection | BLOCKED selection | BLOCKED | BLOCKED | BLOCKED | Unverified | Pending | Current rating for intended phase-current convention |

The grouped pending rows are a coverage checklist, not an assembly BOM.
Do not export or order them. A complete per-reference BOM must be reviewed
before placement and routing; supplier substitutes require new imports and
validation.

## Supplier import evidence

Raw records and converter outputs are preserved in evidence/rev-0.0.2-alpha.0.
Reported LCSC stock from those records: C1525 869375, C23733 100, C25744 235900, C25900 420100, C12084 17337.
These values may be cached; recheck assembly inventory before freezing the BOM.
C52923 / Samsung CL05A105KA5NQNC, 1 uF, 0402, Basic, was also imported as a
support-component candidate but is not instantiated and has no production reference.

The protected PD input, programmer power and IO still require a complete per-reference BOM.
No grouped pending row can be used as a fabrication BOM.

## Additional imported candidates and exclusions (not assembly parts)

- TI TPS259470LRPWR, C3662793, QFN10 / 2 x 2 mm, Extended: exact released
  import retained for input inrush/reverse-current protection investigation; not
  instantiated. [TI datasheet Rev C](https://www.ti.com/lit/ds/symlink/tps25947.pdf).
- C52923 (1 uF) and C25767 (220 kOhm) are unused support candidates.
- C5127775 converter defect is resolved upstream and in this board's official
  regenerated import. Historical generic output imports/C5127775.tsx remains
  excluded; active R5/R6 use imports/HoLRT1206_1W_180mR_1_.tsx.
- C5127776 / Milliohm HoLRT1206-1W-150mR-1%, 1206, 150 mOhm, 1 W, 1%,
  Extended: official native import/pin/pad audit passes; unused electrical
  replacement candidate for C723743. AEC-Q200 qualification is not established.
- C2046441, C5127782 and C723743 remain library-unavailable and excluded.
  C19947652 replaces C2046441 using its own official Bourns footprint;
  C5127775 replaces the unavailable C5127782 electrically.
- Prior C57269 4.7 uH and C723709 200 mOhm imports are retained but no longer
  instantiated. Supplier stock observations below describe historical candidates.
- Raw C167251 identifies BL1084-33-CY LDO and was rejected as an inductor candidate.

The latest supplier pages were observed on 2026-10-02, but cached counts vary.
C57269 JLC page displayed 51,228 stock and 49,442 available order quantity;
C723709 LCSC pages displayed 625 to 2,370 stock; C178585 displayed 525 stock,
while raw library JSON reported 1,798. These differences prevent an inventory
freeze claim. Recheck actual assembler stock from the final BOM before fabrication.

Revision 0.0.4 supplier library identities and Extended classifications were
checked on 2026-10-02 from preserved official records for C19947652, C5127775
and C5127776. Successful import is not proof of assembly stock. Current JLCPCB
assembly inventory for these replacements is unverified and remains a Stage 2
BOM qualification item; no inventory freeze or assembly BOM is claimed.
