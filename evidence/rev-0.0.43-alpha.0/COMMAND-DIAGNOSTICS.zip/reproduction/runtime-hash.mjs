import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
const root=path.resolve('.publication/rev-0.0.43-alpha.0')
const extensions=new Set(['.tsx','.ts','.jsx','.js','.json','.txt','.md','.obj','.kicad_mod','.kicad_pcb','.kicad_pro','.kicad_sch','.kicad_sym'])
const ignored=new Set(['node_modules','dist','build','.git'])
const files=[]
function visit(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){const file=path.join(dir,entry.name);if(entry.isDirectory()){if(!ignored.has(entry.name)&&!entry.name.startsWith('.'))visit(file);continue}if(entry.isFile()&&!entry.name.endsWith('.circuit.json')&&extensions.has(path.extname(entry.name).toLowerCase()))files.push(file)}}
visit(root)
const md5=createHash('md5')
for(const file of files){const relative=path.relative(root,file).split(path.sep).join('/');const content=fs.readFileSync(file);md5.update(`${Buffer.byteLength(relative)}:`);md5.update(relative);md5.update(`${content.byteLength}:`);md5.update(content)}
const computed=md5.digest('hex')
const circuit=JSON.parse(fs.readFileSync(path.join(root,'dist/index/circuit.json'),'utf8'))
const recorded=circuit.find(e=>e.type==='source_project_metadata').source_filesystem_md5_hash
if(computed!==recorded)throw Error('Current runtime filesystem does not match native Circuit JSON metadata')
const receipt={revision:'0.0.43-alpha.0',method:'Read-only replication of pinned official CLI getSourceFilesystemMd5Hash; no metadata or source mutation',source_filesystem_md5_hash:recorded,source_file_count:files.length,current_runtime_matches_native_build:true,prototype_fabrication_ready:false}
fs.writeFileSync('evidence/rev-0.0.43-alpha.0/RUNTIME-SOURCE-HASH.json',JSON.stringify(receipt,null,2)+'\n')
console.log('Actual pinned native runtime MD5 matches:',recorded,'/',files.length,'source files')
