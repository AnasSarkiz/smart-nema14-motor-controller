from pathlib import Path
import subprocess,json,os
root=Path.cwd();out=root/'.publication/fix43';results=[]
for name in ['netlist','placement','source','pin_specification','schematic-placement','shorts']:
 cmd=[str(root/'.cloud-tools/bun/bin/bun'),'x','tsci','check',name,'dist/index/circuit.json' if name=='shorts' else 'index.circuit.tsx']
 with (out/f'cli-supported-{name}.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,cwd=root/'.publication/rev-0.0.43-alpha.0')
 results.append({'name':name,'command':cmd,'exit_code':r.returncode});print(name,r.returncode,flush=True)
 if r.returncode:print((out/f'cli-supported-{name}.log').read_text()[-1200:],flush=True)
(out/'cli-supported-results.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in results))
