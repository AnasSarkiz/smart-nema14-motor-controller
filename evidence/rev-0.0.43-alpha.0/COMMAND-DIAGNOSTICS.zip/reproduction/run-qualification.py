from pathlib import Path
import json, subprocess, sys
root=Path.cwd();out=root/'.publication/fix43';e='evidence/rev-0.0.43-alpha.0';c='dist/index/circuit.json'
nets=[x['name'] for x in json.load(open(c)) if x['type']=='source_net']
commands=[
 ('power-corners',['python3','scripts/check-power-corners.py']),
 ('copper',['.mechanical-venv/bin/python','scripts/check-copper-geometry.py',c,f'{e}/COPPER-GEOMETRY.json','src/routing/thermal-vias-trial.json','src/routing/filled-signal-vias-trial.json']),
 ('filled',['.mechanical-venv/bin/python','scripts/check-filled-copper.py',c,f'{e}/FILLED-COPPER.json',*nets]),
 ('width',['python3','scripts/audit-trace-widths.py',c,f'{e}/TRACE-WIDTH-AUDIT.json']),
 ('tolerance',['python3','scripts/check-fabrication-width-tolerance.py',f'{e}/TRACE-WIDTH-AUDIT.json',f'{e}/FABRICATION-WIDTH-TOLERANCE.json']),
 ('fanouts',['.mechanical-venv/bin/python','scripts/audit-power-fanout-widths.py',c,f'{e}/POWER-FANOUT-WIDTHS.json']),
 ('usb',['python3','scripts/measure-usb-paths.py',c,f'{e}/USB-PATH-MEASUREMENTS.json']),
 ('usb-return',['.mechanical-venv/bin/python','scripts/review-usb-return.py',c,f'{e}/USB-RETURN-REVIEW.json']),
 ('programmer',['python3','scripts/check-programmer-compatibility.py',c,f'{e}/PROGRAMMER-COMPATIBILITY.json']),
 ('notes',['node','scripts/check-schematic-notes.mjs',c,f'{e}/SCHEMATIC-NOTES.json']),
 ('standard-usb',['node','scripts/check-standard-usb-schematic.mjs',c,f'{e}/STANDARD-USB-SCHEMATIC.json']),
 ('bom',['node','scripts/generate-review-bom.mjs']),
 ('catalog',['node','scripts/check-bom-catalog.mjs']),
 ('bom-table',['node','scripts/generate-bom-table.mjs']),
 ('render',['node','scripts/render-schematic-sheets.mjs',c,f'{e}/schematics']),
]
results=[]
for name,cmd in commands:
 with (out/f'{name}.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'exit_code':r.returncode})
 print(name,'PASS' if r.returncode==0 else 'FAIL',flush=True)
 if r.returncode:print((out/f'{name}.log').read_text()[-2000:],flush=True)
(out/'qualification-results.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(any(r['exit_code'] for r in results))
