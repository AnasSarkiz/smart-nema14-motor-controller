import { writeFileSync } from "node:fs"
import { AutoroutingPipelineSolver9_PreloadedTraceGraph, type SimpleRouteJson } from "@tscircuit/capacity-autorouter"

/** Public Pipeline9 input: reserve both inner layers for existing copper. */
export async function routePowerOnOuterLayers(input: SimpleRouteJson) {
  const { minX, maxX, minY, maxY } = input.bounds
  const constrainedInput: SimpleRouteJson = {
    ...input,
    allowBlindAndBuriedVias: false,
    minViaDiameter: 0.45,
    minViaPadDiameter: 0.45,
    min_via_pad_diameter: 0.45,
    minViaHoleDiameter: 0.3,
    min_via_hole_diameter: 0.3,
    obstacles: [
      ...input.obstacles,
      {
        obstacleId: "outer-power-reserved-inner-layers",
        type: "rect",
        layers: ["inner1", "inner2"],
        center: { x: (minX + maxX) / 2, y: (minY + maxY) / 2 },
        width: maxX - minX,
        height: maxY - minY,
        connectedTo: [],
      },
    ],
  }
  writeFileSync(".publication/fix43/outer-v3v3-constrained-input.json", JSON.stringify(constrainedInput, null, 2))
  console.log("Outer-layer constraint applied: Pipeline9", constrainedInput.connections.length, "connections")
  const solver = new AutoroutingPipelineSolver9_PreloadedTraceGraph(constrainedInput, {
    effort: 1,
    maxNodeDimension: 8,
    maxNodeRatio: 12,
    minNodeArea: 0.025,
  })
  let lastYield = performance.now()
  let lastProgress = lastYield
  while (!solver.solved && !solver.failed) {
    solver.step()
    if (performance.now() - lastProgress > 5000) {
      lastProgress = performance.now()
      console.log("Outer Pipeline9", solver.getCurrentPhase(), solver.progress, "failed", solver.failed)
    }
    if (performance.now() - lastYield > 100) {
      lastYield = performance.now()
      await new Promise((resume) => setTimeout(resume, 0))
    }
  }
  if (solver.failed) throw new Error(solver.error || "Outer-layer Pipeline9 failed")
  const output = solver.getOutputSimpleRouteJson()
  writeFileSync(".publication/fix43/outer-v3v3-constrained-output.json", JSON.stringify(output, null, 2))
  return output
}
