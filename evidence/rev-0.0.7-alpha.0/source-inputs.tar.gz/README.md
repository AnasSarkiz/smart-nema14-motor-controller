# Smart NEMA 14 Motor Controller

Revision `0.0.7-alpha.0`, reviewed 2026-10-03 Europe/Tirane.
**Incomplete schematic prototype; not fabrication ready. Routing disabled.**

Standalone USB-C PD stepper-controller design targeting a 35 x 35 mm,
four-layer board, STM32G0B1, TMC2209, optional bottom AS5600 and classical CAN.

The latest official global and local tool updates are installed:
tscircuit 0.0.2736, CLI 0.1.2232, EasyEDA 0.0.368. Critical chips and selected
alternatives were officially regenerated without editing component definitions.
C19947652 is the selected 3.9 uH inductor; C5127775 supplies both 180 mOhm
sense resistors. C5127776 is an unused 150 mOhm option; AEC-Q200 is unverified.
The original three unavailable library imports still fail on the latest release.

Six native A4 sheets now contain 56 JLCPCB parts: MCU, encoder, CAN,
logic regulator, motor-driver support and USB-C/UCPD frontend. The draft
passes 162 physical-pin connection checks. Separate unrouted fixtures audit
104 earlier and 38 new supplier pin-to-pad mappings. These are partial checks,
not proof of a complete working or manufacturing-ready board.

Stage 2 approval is blocked by connector land-pattern discrepancies, imported
custom-symbol output limitations and unqualified power protection/startup.
The GCT connector investigated as an alternative also differs from its drawing
and remains unselected. The protected USB output is not connected to buck or
motor. Inrush/current/reverse protection, motor regeneration, programmer power,
external IO/connectors, temperature and LED circuits remain unfinished.
Exact motor rear mounting/shaft geometry still blocks placement and routing.

Read [VALIDATION.md](VALIDATION.md), [issues.md](issues.md), [BOM.md](BOM.md),
[ARCHITECTURE.md](ARCHITECTURE.md), [USB review](references/USB-PD-REVIEW.md),
[MCU pin plan](references/MCU-PIN-PLAN.md) and [original brief](references/USER-BRIEF.md).
Current evidence, failed import logs and the source archive are under
`evidence/rev-0.0.7-alpha.0/`. Earlier revision evidence remains preserved.
This task's local Git repository has no source commit or remote; checksum
manifests identify the reviewed source/dependency revision.

## Draft checks

Run from this board directory:

```sh
bun install --frozen-lockfile
bun run format:check
bun run typecheck
bun run validate:imports
bun run preview:schematic
bun run test:draft
bun run preview:imports
bun run test:imports
bun run preview:usb-imports
bun run test:usb-imports
```

`dist/index/schematic-{MCU,Encoder,CAN,LogicPower,MotorDriver,UsbPd}.{svg,png}`
are schematic draft previews. Fixture PCB images are isolated geometry checks,
not controller placement. The official JST programming package 0.8.0 is
installed but uninstantiated until its VOUT power interface is resolved.

No controller PCB coordinates, mounting holes, routes, Gerbers, drill files,
assembly BOM/CPL, order or publication has been completed. After the schematic,
BOM, mechanics and placement gates pass, enable routing, inspect actual copper,
run shorts/DRC and routed snapshot checks, then generate/review the identical
revision's prototype fabrication package. Physical hardware testing is pending.
